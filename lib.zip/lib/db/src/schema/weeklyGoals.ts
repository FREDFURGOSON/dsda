import { pgTable, integer, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const weeklyGoalsTable = pgTable("weekly_goals", {
  dayIndex: integer("day_index").primaryKey(),
  goal: text("goal").notNull().default(""),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertWeeklyGoalSchema = createInsertSchema(weeklyGoalsTable).omit({
  updatedAt: true,
});

export type InsertWeeklyGoal = z.infer<typeof insertWeeklyGoalSchema>;
export type WeeklyGoal = typeof weeklyGoalsTable.$inferSelect;
