import { pgTable, text, integer, date, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const userStreaksTable = pgTable("user_streaks", {
  userId: text("user_id").primaryKey(),
  frenchStreak: integer("french_streak").notNull().default(0),
  spanishStreak: integer("spanish_streak").notNull().default(0),
  frenchLastChecked: date("french_last_checked"),
  spanishLastChecked: date("spanish_last_checked"),
  frenchLongest: integer("french_longest").notNull().default(0),
  spanishLongest: integer("spanish_longest").notNull().default(0),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertUserStreakSchema = createInsertSchema(userStreaksTable);
export type InsertUserStreak = z.infer<typeof insertUserStreakSchema>;
export type UserStreak = typeof userStreaksTable.$inferSelect;
