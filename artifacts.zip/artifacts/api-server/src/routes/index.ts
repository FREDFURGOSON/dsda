import { Router, type IRouter } from "express";
import healthRouter from "./health";
import goalsRouter from "./goals";
import authRouter from "./auth";
import streaksRouter from "./streaks";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(goalsRouter);
router.use(streaksRouter);

export default router;
