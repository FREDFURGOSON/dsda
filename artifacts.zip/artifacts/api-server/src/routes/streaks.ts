import { Router } from "express";
import { db } from "@workspace/db";
import { userStreaksTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/streaks", async (req, res) => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const userId = req.user.id;
  const rows = await db.select().from(userStreaksTable).where(eq(userStreaksTable.userId, userId));
  if (rows.length === 0) {
    const row = { userId, frenchStreak: 0, spanishStreak: 0, frenchLastChecked: null, spanishLastChecked: null, frenchLongest: 0, spanishLongest: 0 };
    await db.insert(userStreaksTable).values(row);
    res.json(row);
    return;
  }
  res.json(rows[0]);
});

router.post("/streaks/check-in", async (req, res) => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const { language } = req.body as { language: "french" | "spanish" };
  if (!language || !["french", "spanish"].includes(language)) {
    res.status(400).json({ error: "Invalid language" });
    return;
  }
  const userId = req.user.id;
  const today = new Date().toISOString().split("T")[0];

  const rows = await db.select().from(userStreaksTable).where(eq(userStreaksTable.userId, userId));
  let streak = rows[0] ?? { userId, frenchStreak: 0, spanishStreak: 0, frenchLastChecked: null, spanishLastChecked: null, frenchLongest: 0, spanishLongest: 0 };

  const lastKey = language === "french" ? "frenchLastChecked" : "spanishLastChecked";
  const streakKey = language === "french" ? "frenchStreak" : "spanishStreak";
  const longestKey = language === "french" ? "frenchLongest" : "spanishLongest";

  const last = streak[lastKey];
  let newStreak = streak[streakKey];

  if (last === today) {
    res.json(streak);
    return;
  }

  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split("T")[0];

  if (last === yesterdayStr) {
    newStreak = newStreak + 1;
  } else {
    newStreak = 1;
  }

  const newLongest = Math.max(streak[longestKey], newStreak);
  const update = {
    [lastKey]: today,
    [streakKey]: newStreak,
    [longestKey]: newLongest,
    updatedAt: new Date(),
  };

  if (rows.length === 0) {
    await db.insert(userStreaksTable).values({ ...streak, ...update });
  } else {
    await db.update(userStreaksTable).set(update).where(eq(userStreaksTable.userId, userId));
  }

  const updated = { ...streak, ...update };
  res.json(updated);
});

export default router;
