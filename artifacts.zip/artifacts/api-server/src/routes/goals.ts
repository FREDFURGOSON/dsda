import { Router, type IRouter } from "express";
import { db, weeklyGoalsTable } from "@workspace/db";
import {
  GetWeeklyGoalsResponse,
  SetWeeklyGoalsBody,
  SetWeeklyGoalsResponse,
  GetTodayGoalResponse,
} from "@workspace/api-zod";
import { eq } from "drizzle-orm";

const router: IRouter = Router();

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

async function ensureGoalsExist() {
  const existing = await db.select().from(weeklyGoalsTable);
  if (existing.length < 7) {
    const existingIndices = new Set(existing.map((r) => r.dayIndex));
    const toInsert = [];
    for (let i = 0; i < 7; i++) {
      if (!existingIndices.has(i)) {
        toInsert.push({ dayIndex: i, goal: "" });
      }
    }
    if (toInsert.length > 0) {
      await db.insert(weeklyGoalsTable).values(toInsert);
    }
  }
}

router.get("/goals", async (req, res) => {
  await ensureGoalsExist();
  const rows = await db.select().from(weeklyGoalsTable).orderBy(weeklyGoalsTable.dayIndex);
  const data = GetWeeklyGoalsResponse.parse({
    goals: rows.map((r) => ({
      day: DAYS[r.dayIndex],
      dayIndex: r.dayIndex,
      goal: r.goal,
    })),
  });
  res.json(data);
});

router.put("/goals", async (req, res) => {
  const body = SetWeeklyGoalsBody.parse(req.body);
  await ensureGoalsExist();

  for (let i = 0; i < 7; i++) {
    await db
      .update(weeklyGoalsTable)
      .set({ goal: body.goals[i] ?? "", updatedAt: new Date() })
      .where(eq(weeklyGoalsTable.dayIndex, i));
  }

  const rows = await db.select().from(weeklyGoalsTable).orderBy(weeklyGoalsTable.dayIndex);
  const data = SetWeeklyGoalsResponse.parse({
    goals: rows.map((r) => ({
      day: DAYS[r.dayIndex],
      dayIndex: r.dayIndex,
      goal: r.goal,
    })),
  });
  res.json(data);
});

router.get("/goals/today", async (req, res) => {
  await ensureGoalsExist();
  const todayIndex = new Date().getDay();
  const rows = await db
    .select()
    .from(weeklyGoalsTable)
    .where(eq(weeklyGoalsTable.dayIndex, todayIndex));
  const row = rows[0] ?? { dayIndex: todayIndex, goal: "" };
  const data = GetTodayGoalResponse.parse({
    day: DAYS[todayIndex],
    dayIndex: todayIndex,
    goal: row.goal,
  });
  res.json(data);
});

export default router;
