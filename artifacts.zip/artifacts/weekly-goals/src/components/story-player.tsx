import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Play, Pause, SkipForward, SkipBack, Volume2,
  BookOpen, MessageSquare, Lightbulb, Dumbbell, Star, ChevronDown, ChevronUp
} from "lucide-react";
import type { Story, StorySegment } from "@/data/stories";

interface StoryPlayerProps {
  story: Story;
  locale: string;
  accentColor: string;
  accentColorLight: string;
  speed: number;
}

function pickVoice(locale: string, voices: SpeechSynthesisVoice[]): SpeechSynthesisVoice | null {
  const [lang] = locale.split("-");
  return (
    voices.find(v => v.lang.toLowerCase() === locale.toLowerCase()) ||
    voices.find(v => v.lang.toLowerCase().startsWith(lang.toLowerCase() + "-")) ||
    voices.find(v => v.lang.toLowerCase().startsWith(lang.toLowerCase())) ||
    null
  );
}

const SEGMENT_ICONS: Record<StorySegment["type"], React.ReactNode> = {
  intro: <BookOpen className="w-4 h-4" />,
  phrase: <Volume2 className="w-4 h-4" />,
  dialogue: <MessageSquare className="w-4 h-4" />,
  story: <BookOpen className="w-4 h-4" />,
  practice: <Dumbbell className="w-4 h-4" />,
  tip: <Lightbulb className="w-4 h-4" />,
};

const SEGMENT_LABELS: Record<StorySegment["type"], string> = {
  intro: "Narrator",
  phrase: "Key Phrase",
  dialogue: "Dialogue",
  story: "Story",
  practice: "Practice",
  tip: "Tip",
};

const SEGMENT_COLORS: Record<StorySegment["type"], string> = {
  intro: "rgba(148,163,184,0.15)",
  phrase: "rgba(167,139,250,0.12)",
  dialogue: "rgba(56,189,248,0.12)",
  story: "rgba(52,211,153,0.12)",
  practice: "rgba(251,191,36,0.12)",
  tip: "rgba(249,115,22,0.12)",
};
const SEGMENT_BORDER: Record<StorySegment["type"], string> = {
  intro: "rgba(148,163,184,0.25)",
  phrase: "rgba(167,139,250,0.35)",
  dialogue: "rgba(56,189,248,0.35)",
  story: "rgba(52,211,153,0.35)",
  practice: "rgba(251,191,36,0.35)",
  tip: "rgba(249,115,22,0.35)",
};
const SEGMENT_TEXT: Record<StorySegment["type"], string> = {
  intro: "#94a3b8",
  phrase: "#a78bfa",
  dialogue: "#38bdf8",
  story: "#34d399",
  practice: "#fbbf24",
  tip: "#f97316",
};

function DifficultyStars({ count }: { count: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className="w-3 h-3"
          style={{ color: i < count ? "#fbbf24" : "rgba(255,255,255,0.15)", fill: i < count ? "#fbbf24" : "none" }}
        />
      ))}
    </div>
  );
}

export function StoryPlayer({ story, locale, accentColor, accentColorLight, speed }: StoryPlayerProps) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [showAll, setShowAll] = useState(false);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const playingRef = useRef(false);

  useEffect(() => {
    const load = () => {
      const v = window.speechSynthesis.getVoices();
      if (v.length > 0) setVoices(v);
    };
    load();
    window.speechSynthesis.onvoiceschanged = load;
    return () => { window.speechSynthesis.onvoiceschanged = null; };
  }, []);

  useEffect(() => () => {
    playingRef.current = false;
    window.speechSynthesis.cancel();
  }, []);

  const getSegmentText = useCallback((seg: StorySegment): string => {
    if (seg.type === "intro" || seg.type === "tip") return seg.english;
    if (seg.type === "phrase" || seg.type === "dialogue" || seg.type === "story" || seg.type === "practice") {
      return seg.foreign ?? seg.english;
    }
    return seg.english;
  }, []);

  const getSegmentLocale = useCallback((seg: StorySegment): string => {
    if (seg.type === "intro" || seg.type === "tip") return "en-US";
    return locale;
  }, [locale]);

  const speakSegment = useCallback((idx: number, allVoices: SpeechSynthesisVoice[]) => {
    const seg = story.segments[idx];
    if (!seg) return;

    window.speechSynthesis.cancel();
    const text = getSegmentText(seg);
    const segLocale = getSegmentLocale(seg);

    const u = new SpeechSynthesisUtterance(text);
    u.lang = segLocale;
    u.rate = segLocale === "en-US" ? Math.min(speed, 1.4) : speed;
    u.pitch = 1.0;

    const v = segLocale === "en-US"
      ? (allVoices.find(v => v.lang.toLowerCase().startsWith("en")) ?? null)
      : pickVoice(locale, allVoices);
    if (v) u.voice = v;

    u.onend = () => {
      if (!playingRef.current) return;
      const next = idx + 1;
      if (next < story.segments.length) {
        setCurrentIdx(next);
        setTimeout(() => speakSegment(next, window.speechSynthesis.getVoices()), 800);
      } else {
        setIsPlaying(false);
        playingRef.current = false;
      }
    };
    u.onerror = (e) => {
      if (e.error === "interrupted") return;
      setIsPlaying(false);
      playingRef.current = false;
    };

    utteranceRef.current = u;
    window.speechSynthesis.speak(u);
  }, [story.segments, getSegmentText, getSegmentLocale, locale, speed]);

  const handlePlay = useCallback(() => {
    if (isPlaying) {
      playingRef.current = false;
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    } else {
      playingRef.current = true;
      setIsPlaying(true);
      const v = window.speechSynthesis.getVoices().length > 0
        ? window.speechSynthesis.getVoices()
        : voices;
      speakSegment(currentIdx, v);
    }
  }, [isPlaying, currentIdx, voices, speakSegment]);

  const goTo = useCallback((idx: number) => {
    playingRef.current = false;
    window.speechSynthesis.cancel();
    setIsPlaying(false);
    setCurrentIdx(idx);
  }, []);

  const speakCurrentOnly = useCallback(() => {
    playingRef.current = false;
    window.speechSynthesis.cancel();
    setIsPlaying(false);
    const v = window.speechSynthesis.getVoices().length > 0 ? window.speechSynthesis.getVoices() : voices;
    const seg = story.segments[currentIdx];
    const text = getSegmentText(seg);
    const segLocale = getSegmentLocale(seg);
    const u = new SpeechSynthesisUtterance(text);
    u.lang = segLocale;
    u.rate = segLocale === "en-US" ? Math.min(speed, 1.4) : speed;
    u.pitch = 1.0;
    const voice = segLocale === "en-US"
      ? (v.find(x => x.lang.toLowerCase().startsWith("en")) ?? null)
      : pickVoice(locale, v);
    if (voice) u.voice = voice;
    window.speechSynthesis.speak(u);
  }, [currentIdx, story.segments, getSegmentText, getSegmentLocale, locale, speed, voices]);

  const seg = story.segments[currentIdx];
  const progress = ((currentIdx + 1) / story.segments.length) * 100;
  const displaySegments = showAll ? story.segments : story.segments.slice(0, 4);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-foreground">{story.nativeTitle}</h2>
          </div>
          <p className="text-xs text-muted-foreground italic">{story.title} · {story.theme}</p>
          <div className="flex items-center gap-3 pt-0.5">
            <DifficultyStars count={story.difficulty} />
            <span className="text-xs text-muted-foreground">~{story.estimatedMinutes} min lesson</span>
          </div>
        </div>
        <span
          className="text-xs font-bold px-3 py-1.5 rounded-full shrink-0"
          style={{ background: accentColorLight, color: accentColor }}
        >
          Lesson {story.difficulty === 1 ? "Beginner" : story.difficulty === 2 ? "Elementary" : story.difficulty === 3 ? "Intermediate" : story.difficulty === 4 ? "Advanced" : "Expert"}
        </span>
      </div>

      {/* Progress bar */}
      <div className="space-y-1.5">
        <div className="flex justify-between text-[10px] text-muted-foreground font-medium">
          <span>Step {currentIdx + 1} of {story.segments.length}</span>
          <span>{Math.round(progress)}% complete</span>
        </div>
        <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
          <motion.div
            className="h-full rounded-full"
            style={{ background: accentColor }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.4, ease: "easeOut" }}
          />
        </div>
      </div>

      {/* Current segment display */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIdx}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.25 }}
          className="rounded-xl border p-5 space-y-4"
          style={{
            borderColor: SEGMENT_BORDER[seg.type],
            background: SEGMENT_COLORS[seg.type],
          }}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2" style={{ color: SEGMENT_TEXT[seg.type] }}>
              {SEGMENT_ICONS[seg.type]}
              <span className="text-xs font-bold uppercase tracking-widest">{SEGMENT_LABELS[seg.type]}</span>
            </div>
            <button
              onClick={speakCurrentOnly}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all active:scale-95"
              style={{
                background: "rgba(255,255,255,0.06)",
                color: accentColor,
                border: `1px solid ${accentColor}40`,
              }}
            >
              <Volume2 className="w-3 h-3" />
              Listen
            </button>
          </div>

          {/* Foreign text (for non-intro/tip) */}
          {seg.foreign && (
            <p
              className="text-base md:text-lg font-semibold leading-relaxed text-foreground whitespace-pre-line"
              lang={locale.split("-")[0]}
            >
              {seg.foreign}
            </p>
          )}

          {/* English */}
          <p className={`leading-relaxed whitespace-pre-line ${seg.foreign ? "text-sm text-muted-foreground italic" : "text-base text-foreground"}`}>
            {seg.english}
          </p>

          {/* Practice prompt */}
          {seg.prompt && (
            <div
              className="rounded-lg p-3 text-sm text-foreground/80"
              style={{ background: "rgba(255,255,255,0.05)", borderLeft: `3px solid ${accentColor}` }}
            >
              {seg.prompt}
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Playback controls */}
      <div className="flex items-center justify-center gap-3">
        <button
          onClick={() => goTo(Math.max(0, currentIdx - 1))}
          disabled={currentIdx === 0}
          className="w-10 h-10 rounded-full flex items-center justify-center border transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:border-white/30"
          style={{ borderColor: "rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.05)" }}
        >
          <SkipBack className="w-4 h-4 text-muted-foreground" />
        </button>

        <button
          onClick={handlePlay}
          className="w-14 h-14 rounded-full flex items-center justify-center transition-all active:scale-95 shadow-lg"
          style={{ background: accentColor }}
        >
          {isPlaying
            ? <Pause className="w-6 h-6 text-white fill-white" />
            : <Play className="w-6 h-6 text-white fill-white ml-0.5" />}
        </button>

        <button
          onClick={() => goTo(Math.min(story.segments.length - 1, currentIdx + 1))}
          disabled={currentIdx === story.segments.length - 1}
          className="w-10 h-10 rounded-full flex items-center justify-center border transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:border-white/30"
          style={{ borderColor: "rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.05)" }}
        >
          <SkipForward className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>

      {/* All segments list */}
      <div className="space-y-2">
        <button
          onClick={() => setShowAll(s => !s)}
          className="flex items-center gap-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors"
        >
          {showAll ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          {showAll ? "Hide" : "Show"} all {story.segments.length} steps
        </button>

        <AnimatePresence>
          {showAll && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-1 overflow-hidden"
            >
              {story.segments.map((s, i) => (
                <button
                  key={i}
                  onClick={() => goTo(i)}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all"
                  style={{
                    background: i === currentIdx ? `${accentColor}18` : "transparent",
                    border: `1px solid ${i === currentIdx ? `${accentColor}40` : "transparent"}`,
                  }}
                >
                  <span
                    className="w-5 h-5 rounded-full text-[10px] font-bold flex items-center justify-center shrink-0"
                    style={{
                      background: i <= currentIdx ? accentColor : "rgba(255,255,255,0.1)",
                      color: i <= currentIdx ? "white" : "rgba(255,255,255,0.4)",
                    }}
                  >
                    {i < currentIdx ? "✓" : i + 1}
                  </span>
                  <span className="text-xs" style={{ color: SEGMENT_TEXT[s.type] }}>
                    {SEGMENT_LABELS[s.type]}
                  </span>
                  <span className="text-xs text-muted-foreground truncate flex-1">
                    {s.foreign ? s.foreign.substring(0, 40) + (s.foreign.length > 40 ? "…" : "") : s.english.substring(0, 40) + (s.english.length > 40 ? "…" : "")}
                  </span>
                </button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
