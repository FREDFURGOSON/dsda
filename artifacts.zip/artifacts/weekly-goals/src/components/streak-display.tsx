import { motion } from "framer-motion";
import { Flame } from "lucide-react";

interface StreakDisplayProps {
  frenchStreak: number;
  spanishStreak: number;
  frenchLongest: number;
  spanishLongest: number;
}

function StreakBadge({
  label,
  flag,
  streak,
  longest,
  color,
  colorLight,
}: {
  label: string;
  flag: string;
  streak: number;
  longest: number;
  color: string;
  colorLight: string;
}) {
  const isActive = streak > 0;
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      className="flex flex-col gap-2 rounded-2xl border p-4"
      style={{
        borderColor: isActive ? `${color}40` : "rgba(255,255,255,0.07)",
        background: isActive ? `${color}08` : "rgba(255,255,255,0.02)",
      }}
    >
      <div className="flex items-center gap-2">
        <span className="text-xl">{flag}</span>
        <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider">{label}</span>
      </div>

      <div className="flex items-end gap-2">
        <motion.div
          key={streak}
          initial={{ scale: 1.3, opacity: 0.7 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 300, damping: 20 }}
          className="flex items-center gap-1"
        >
          <Flame
            className="w-7 h-7"
            style={{ color: isActive ? color : "rgba(255,255,255,0.2)", fill: isActive ? `${color}40` : "none" }}
          />
          <span
            className="text-3xl font-black leading-none"
            style={{ color: isActive ? color : "rgba(255,255,255,0.3)" }}
          >
            {streak}
          </span>
        </motion.div>
        <span className="text-xs text-muted-foreground pb-1">
          {streak === 1 ? "day" : "days"}
        </span>
      </div>

      {longest > 0 && (
        <p className="text-[10px] text-muted-foreground">
          Best: {longest} {longest === 1 ? "day" : "days"}
        </p>
      )}

      {streak === 0 && (
        <p className="text-[10px] text-muted-foreground italic">Start your streak today!</p>
      )}
    </motion.div>
  );
}

export function StreakDisplay({ frenchStreak, spanishStreak, frenchLongest, spanishLongest }: StreakDisplayProps) {
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Flame className="w-4 h-4 text-orange-400" />
        <h2 className="text-base font-bold text-foreground">Daily Streaks</h2>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <StreakBadge
          label="French"
          flag="🇫🇷"
          streak={frenchStreak}
          longest={frenchLongest}
          color="#a78bfa"
          colorLight="rgba(167,139,250,0.15)"
        />
        <StreakBadge
          label="Spanish"
          flag="🇩🇴"
          streak={spanishStreak}
          longest={spanishLongest}
          color="#38bdf8"
          colorLight="rgba(56,189,248,0.15)"
        />
      </div>
    </div>
  );
}
