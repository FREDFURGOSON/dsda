import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Volume2, RotateCcw, ChevronLeft, ChevronRight } from "lucide-react";
import type { VocabWord } from "@/data/vocabulary";

interface FlashcardsProps {
  words: VocabWord[];
  locale: string;
  accentColor: string;
  accentColorLight: string;
  speed?: number;
}

function speakWord(text: string, locale: string, speed: number) {
  window.speechSynthesis.cancel();
  const voices = window.speechSynthesis.getVoices();
  const [lang] = locale.split("-");
  const voice =
    voices.find(v => v.lang.toLowerCase() === locale.toLowerCase()) ||
    voices.find(v => v.lang.toLowerCase().startsWith(lang.toLowerCase() + "-")) ||
    voices.find(v => v.lang.toLowerCase().startsWith(lang.toLowerCase())) ||
    null;
  const u = new SpeechSynthesisUtterance(text);
  u.lang = locale;
  u.rate = speed;
  u.pitch = 1.0;
  if (voice) u.voice = voice;
  window.speechSynthesis.speak(u);
}

function FlipCard({
  word,
  locale,
  accentColor,
  accentColorLight,
  index,
  speed,
}: {
  word: VocabWord;
  locale: string;
  accentColor: string;
  accentColorLight: string;
  index: number;
  speed: number;
}) {
  const [flipped, setFlipped] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const handleSpeak = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsSpeaking(true);
    window.speechSynthesis.cancel();
    const voices = window.speechSynthesis.getVoices();
    const [lang] = locale.split("-");
    const voice =
      voices.find(v => v.lang.toLowerCase() === locale.toLowerCase()) ||
      voices.find(v => v.lang.toLowerCase().startsWith(lang.toLowerCase() + "-")) ||
      null;
    const u = new SpeechSynthesisUtterance(word.foreign);
    u.lang = locale;
    u.rate = speed;
    u.pitch = 1.0;
    if (voice) u.voice = voice;
    u.onend = () => setIsSpeaking(false);
    u.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(u);
  };

  const posColors: Record<string, string> = {
    noun: "rgba(167,139,250,0.2)",
    verb: "rgba(56,189,248,0.2)",
    adjective: "rgba(251,191,36,0.2)",
    adverb: "rgba(52,211,153,0.2)",
    conjunction: "rgba(248,113,113,0.2)",
  };
  const posTextColors: Record<string, string> = {
    noun: "#a78bfa",
    verb: "#38bdf8",
    adjective: "#fbbf24",
    adverb: "#34d399",
    conjunction: "#f87171",
  };
  const posBg = posColors[word.partOfSpeech] ?? "rgba(255,255,255,0.1)";
  const posText = posTextColors[word.partOfSpeech] ?? "#fff";

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, delay: index * 0.04 }}
      className="relative"
      style={{ perspective: "800px" }}
    >
      <div
        className="cursor-pointer select-none"
        onClick={() => setFlipped(f => !f)}
        style={{ transformStyle: "preserve-3d", transition: "transform 0.5s cubic-bezier(0.23,1,0.32,1)", transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)", position: "relative", minHeight: "130px" }}
      >
        {/* Front */}
        <div
          className="absolute inset-0 rounded-xl border flex flex-col items-center justify-center p-4 text-center gap-2"
          style={{
            backfaceVisibility: "hidden",
            WebkitBackfaceVisibility: "hidden",
            borderColor: flipped ? "transparent" : `${accentColor}30`,
            background: flipped ? "transparent" : `${accentColor}08`,
          }}
        >
          <p className="text-base font-bold text-foreground leading-tight">
            {word.foreign}
          </p>
          <span
            className="text-[10px] font-semibold uppercase tracking-widest px-2 py-0.5 rounded-full"
            style={{ background: posBg, color: posText }}
          >
            {word.partOfSpeech}
          </span>
          <p className="text-[10px] text-muted-foreground mt-1">tap to flip</p>
        </div>

        {/* Back */}
        <div
          className="absolute inset-0 rounded-xl border flex flex-col items-center justify-center p-4 text-center gap-2"
          style={{
            backfaceVisibility: "hidden",
            WebkitBackfaceVisibility: "hidden",
            transform: "rotateY(180deg)",
            borderColor: "rgba(52,211,153,0.3)",
            background: "rgba(52,211,153,0.06)",
          }}
        >
          <p className="text-sm font-semibold text-emerald-300 leading-tight">
            {word.english}
          </p>
          <p className="text-[10px] text-muted-foreground font-medium">
            {word.foreign}
          </p>
        </div>
      </div>

      {/* Speaker button — always visible, outside the flip */}
      <button
        onClick={handleSpeak}
        className="absolute top-2 right-2 w-6 h-6 rounded-full flex items-center justify-center transition-all duration-150 z-10"
        style={{
          background: isSpeaking ? accentColor : "rgba(255,255,255,0.07)",
          color: isSpeaking ? "#fff" : accentColor,
          border: `1px solid ${accentColor}40`,
        }}
        title="Listen"
        aria-label="Listen to pronunciation"
      >
        <Volume2 className="w-3 h-3" />
      </button>
    </motion.div>
  );
}

export function FlashcardSection({ words, locale, accentColor, accentColorLight, speed = 0.88 }: FlashcardsProps) {
  const [page, setPage] = useState(0);
  const [key, setKey] = useState(0);
  const pageSize = 6;
  const totalPages = Math.ceil(words.length / pageSize);
  const pageWords = words.slice(page * pageSize, page * pageSize + pageSize);

  const reset = useCallback(() => {
    setKey(k => k + 1);
    setPage(0);
  }, []);

  return (
    <div className="space-y-5">
      {/* Section header */}
      <div className="flex items-center justify-between gap-3">
        <div className="space-y-0.5">
          <h2 className="text-xl font-bold tracking-tight text-foreground">
            Today's Vocabulary
          </h2>
          <p className="text-xs text-muted-foreground">
            {words.length} new words · tap a card to reveal the translation
          </p>
        </div>
        <button
          onClick={reset}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold text-muted-foreground hover:text-foreground border border-border/50 hover:border-border transition-all"
          title="Reset all cards"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reset
        </button>
      </div>

      {/* Card grid */}
      <div key={key} className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {pageWords.map((word, i) => (
          <FlipCard
            key={`${page}-${i}`}
            word={word}
            locale={locale}
            accentColor={accentColor}
            accentColorLight={accentColorLight}
            index={i}
            speed={speed}
          />
        ))}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between pt-1">
          <button
            onClick={() => setPage(p => Math.max(0, p - 1))}
            disabled={page === 0}
            className="flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold border border-border/50 disabled:opacity-30 disabled:cursor-not-allowed hover:border-border transition-all text-muted-foreground hover:text-foreground"
          >
            <ChevronLeft className="w-3.5 h-3.5" /> Prev
          </button>

          <div className="flex items-center gap-1.5">
            {Array.from({ length: totalPages }).map((_, i) => (
              <button
                key={i}
                onClick={() => setPage(i)}
                className="w-2 h-2 rounded-full transition-all duration-200"
                style={{
                  background: i === page ? accentColor : "rgba(255,255,255,0.15)",
                  transform: i === page ? "scale(1.3)" : "scale(1)",
                }}
              />
            ))}
          </div>

          <button
            onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
            disabled={page === totalPages - 1}
            className="flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold border border-border/50 disabled:opacity-30 disabled:cursor-not-allowed hover:border-border transition-all text-muted-foreground hover:text-foreground"
          >
            Next <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
}
