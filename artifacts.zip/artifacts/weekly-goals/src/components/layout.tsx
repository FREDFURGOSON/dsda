import { Link, useLocation } from "wouter";
import { LayoutDashboard, Settings2, LogIn, LogOut, User } from "lucide-react";
import { motion } from "framer-motion";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { format } from "date-fns";
import { useAuth } from "@workspace/replit-auth-web";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const TODAY = format(new Date(), "yyyy-MM-dd");

function isLangChecked(lang: string) {
  try { return localStorage.getItem(`rhythm-lang-checked-${lang}-${TODAY}`) === "true"; } catch { return false; }
}

const NAV_LINKS = [
  { href: "/french", label: "🇫🇷 French", lang: "french" },
  { href: "/spanish", label: "🇪🇸 Spanish", lang: "spanish" },
];

function AuthButton() {
  const { user, isLoading, isAuthenticated, login, logout } = useAuth();
  if (isLoading) return null;
  if (isAuthenticated) {
    return (
      <button
        onClick={logout}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border border-border/50 text-muted-foreground hover:text-foreground hover:border-border transition-all ml-2 shrink-0"
        title={`Logged in as ${user?.firstName ?? user?.username ?? "you"}`}
      >
        <User className="w-3.5 h-3.5" />
        <span className="hidden sm:inline max-w-[80px] truncate">{user?.firstName ?? user?.username ?? "Account"}</span>
        <LogOut className="w-3 h-3 opacity-60" />
      </button>
    );
  }
  return (
    <button
      onClick={login}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all ml-2 shrink-0"
      style={{ borderColor: "rgba(167,139,250,0.4)", color: "#a78bfa", background: "rgba(167,139,250,0.08)" }}
    >
      <LogIn className="w-3.5 h-3.5" />
      <span className="hidden sm:inline">Log in</span>
    </button>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen flex flex-col selection:bg-primary/10">
      <header className="sticky top-0 z-50 bg-black/30 backdrop-blur-xl border-b border-white/8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group outline-none focus-visible:ring-2 focus-visible:ring-primary rounded-lg p-1 flex-shrink-0">
            <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center text-primary-foreground shadow-sm group-hover:scale-105 transition-transform duration-300">
              <LayoutDashboard className="w-4 h-4" />
            </div>
            <span className="font-bold text-lg tracking-tight text-foreground hidden sm:block">
              Rhythm
            </span>
          </Link>

          {/* Nav */}
          <nav className="flex items-center gap-1 flex-1 justify-center sm:justify-end flex-wrap">
            {NAV_LINKS.map(({ href, label, lang }) => {
              const done = isLangChecked(lang);
              return (
                <Link
                  key={href}
                  href={href}
                  className={cn(
                    "relative flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium transition-all duration-200 outline-none focus-visible:ring-2 focus-visible:ring-primary",
                    location === href
                      ? "bg-secondary text-secondary-foreground shadow-sm"
                      : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                  )}
                >
                  {label}
                  {done && (
                    <span className="w-2 h-2 rounded-full bg-emerald-400 flex-shrink-0" title="Completed today" />
                  )}
                </Link>
              );
            })}

            <Link
              href="/edit"
              className={cn(
                "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium transition-all duration-200 outline-none focus-visible:ring-2 focus-visible:ring-primary",
                location === "/edit"
                  ? "bg-secondary text-secondary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground hover:bg-white/5"
              )}
            >
              <Settings2 className="w-4 h-4" />
              <span className="hidden sm:inline">Goals</span>
            </Link>
          </nav>
          <AuthButton />
        </div>
      </header>

      <main className="flex-1 max-w-4xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        <motion.div
          key={location}
          initial={{ opacity: 0, y: 10, filter: "blur(4px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          exit={{ opacity: 0, y: -10, filter: "blur(4px)" }}
          transition={{ duration: 0.3, ease: "easeOut" }}
        >
          {children}
        </motion.div>
      </main>

      <footer className="py-8 border-t border-white/8 mt-auto">
        <div className="max-w-4xl mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>Find your rhythm. One intention per day.</p>
        </div>
      </footer>
    </div>
  );
}
