import { useState, useEffect } from "react";
import { useGetTodayGoal, useGetWeeklyGoals } from "@workspace/api-client-react";
import { Card, Button } from "@/components/ui-elements";
import { Link } from "wouter";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { CalendarDays, Check, ChevronRight, Sparkles, Circle, Flame, LogIn } from "lucide-react";
import { useAuth } from "@workspace/replit-auth-web";

const TODAY_KEY = format(new Date(), "yyyy-MM-dd");
const STORAGE_KEY = `rhythm-checked-${TODAY_KEY}`;

function loadChecked(): Record<number, boolean> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function saveChecked(state: Record<number, boolean>) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

const TODAY_LANG_KEY_FR = `rhythm-lang-checked-french-${TODAY_KEY}`;
const TODAY_LANG_KEY_ES = `rhythm-lang-checked-spanish-${TODAY_KEY}`;

function computeLocalStreak(lang: string): number {
  let streak = 0;
  const d = new Date();
  for (let i = 0; i < 365; i++) {
    const dateStr = format(new Date(d.getTime() - i * 86400000), "yyyy-MM-dd");
    const done = localStorage.getItem(`rhythm-lang-checked-${lang}-${dateStr}`) === "true";
    if (done) streak++;
    else if (i > 0) break;
  }
  return streak;
}

export default function Home() {
  const { data: todayData, isLoading: todayLoading } = useGetTodayGoal();
  const { data: weeklyData, isLoading: weeklyLoading } = useGetWeeklyGoals();
  const [checked, setChecked] = useState<Record<number, boolean>>(loadChecked);
  const { isAuthenticated, isLoading: authLoading, login } = useAuth();

  const [frenchDoneToday, setFrenchDoneToday] = useState(() => {
    try { return localStorage.getItem(TODAY_LANG_KEY_FR) === "true"; } catch { return false; }
  });
  const [spanishDoneToday, setSpanishDoneToday] = useState(() => {
    try { return localStorage.getItem(TODAY_LANG_KEY_ES) === "true"; } catch { return false; }
  });

  const [apiStreak, setApiStreak] = useState<{ frenchStreak: number; spanishStreak: number; frenchLongest: number; spanishLongest: number } | null>(null);

  useEffect(() => {
    if (!isAuthenticated) return;
    fetch("/api/streaks", { credentials: "include" })
      .then(r => r.ok ? r.json() : null)
      .then(d => d && setApiStreak(d))
      .catch(() => {});
  }, [isAuthenticated]);

  useEffect(() => {
    const handler = () => {
      setFrenchDoneToday(localStorage.getItem(TODAY_LANG_KEY_FR) === "true");
      setSpanishDoneToday(localStorage.getItem(TODAY_LANG_KEY_ES) === "true");
    };
    window.addEventListener("storage", handler);
    return () => window.removeEventListener("storage", handler);
  }, []);

  const localFrenchStreak = computeLocalStreak("french");
  const localSpanishStreak = computeLocalStreak("spanish");
  const frenchStreak = apiStreak?.frenchStreak ?? localFrenchStreak;
  const spanishStreak = apiStreak?.spanishStreak ?? localSpanishStreak;

  useEffect(() => {
    saveChecked(checked);
  }, [checked]);

  const toggleCheck = (dayIndex: number) => {
    setChecked(prev => ({ ...prev, [dayIndex]: !prev[dayIndex] }));
  };

  const isLoading = todayLoading || weeklyLoading;
  const currentDate = format(new Date(), "MMMM do, yyyy");

  if (isLoading) {
    return (
      <div className="space-y-8 animate-pulse">
        <div className="h-8 w-48 bg-muted rounded-lg" />
        <div className="h-64 bg-muted/30 rounded-2xl" />
      </div>
    );
  }

  const todayGoal = todayData?.goal;
  const todayIndex = todayData?.dayIndex ?? new Date().getDay();
  const isTodayChecked = !!checked[todayIndex];
  const hasGoalsSet = weeklyData?.goals.some(g => g.goal && g.goal.trim().length > 0);

  return (
    <div className="space-y-12 pb-12">

      {/* Language Streak Section */}
      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <Flame className="w-4 h-4 text-orange-400" />
          <h2 className="text-base font-bold text-foreground">Language Streaks</h2>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {[
            { lang: "french", flag: "🇫🇷", label: "French", streak: frenchStreak, done: frenchDoneToday, color: "#a78bfa", href: "/french" },
            { lang: "spanish", flag: "🇩🇴", label: "Spanish", streak: spanishStreak, done: spanishDoneToday, color: "#38bdf8", href: "/spanish" },
          ].map(({ lang, flag, label, streak, done, color, href }) => (
            <motion.div
              key={lang}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.35 }}
            >
              <Link href={href}>
                <div
                  className="relative rounded-2xl border p-4 space-y-3 cursor-pointer transition-all duration-200 hover:scale-[1.02]"
                  style={{
                    borderColor: done ? `${color}50` : "rgba(255,255,255,0.07)",
                    background: done ? `${color}08` : "rgba(255,255,255,0.02)",
                  }}
                >
                  {done && (
                    <div
                      className="absolute top-3 right-3 w-5 h-5 rounded-full flex items-center justify-center"
                      style={{ background: "#34d399" }}
                    >
                      <Check className="w-3 h-3 text-white stroke-[3]" />
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{flag}</span>
                    <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider">{label}</span>
                  </div>
                  <div className="flex items-end gap-1.5">
                    <Flame
                      className="w-6 h-6"
                      style={{ color: streak > 0 ? color : "rgba(255,255,255,0.2)", fill: streak > 0 ? `${color}30` : "none" }}
                    />
                    <span className="text-2xl font-black leading-none" style={{ color: streak > 0 ? color : "rgba(255,255,255,0.3)" }}>
                      {streak}
                    </span>
                    <span className="text-xs text-muted-foreground pb-0.5">{streak === 1 ? "day" : "days"}</span>
                  </div>
                  {!done && (
                    <p className="text-[10px] text-muted-foreground">Practice today to keep your streak!</p>
                  )}
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
        {!isAuthenticated && !authLoading && (
          <motion.div
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.2 }}
            className="rounded-xl border border-border/40 px-4 py-3 flex items-center justify-between gap-3"
            style={{ background: "rgba(167,139,250,0.05)" }}
          >
            <p className="text-xs text-muted-foreground">
              <span className="text-foreground font-semibold">Log in</span> to save your streaks across devices
            </p>
            <button
              onClick={login}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold shrink-0 transition-all"
              style={{ background: "rgba(167,139,250,0.15)", color: "#a78bfa", border: "1px solid rgba(167,139,250,0.3)" }}
            >
              <LogIn className="w-3 h-3" />
              Log in
            </button>
          </motion.div>
        )}
      </section>

      {/* Today Section */}
      <section className="space-y-6">
        <div className="space-y-1">
          <p className="text-muted-foreground font-medium flex items-center gap-2">
            <CalendarDays className="w-4 h-4" />
            {currentDate}
          </p>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-foreground">
            Happy {todayData?.day || format(new Date(), "EEEE")}.
          </h1>
        </div>

        {todayGoal ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.1, ease: [0.23, 1, 0.32, 1] }}
          >
            <div
              className={`relative overflow-hidden rounded-2xl border p-8 md:p-12 transition-all duration-500 ${
                isTodayChecked
                  ? "border-emerald-500/40 bg-emerald-500/10 shadow-lg shadow-emerald-500/10"
                  : "border-primary/20 bg-card shadow-xl shadow-primary/5"
              }`}
            >
              {/* Left accent bar */}
              <div
                className={`absolute top-0 left-0 w-1 h-full rounded-l-2xl transition-colors duration-500 ${
                  isTodayChecked ? "bg-emerald-400" : "bg-primary"
                }`}
              />

              <div className="space-y-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-3 flex-1">
                    <span
                      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm font-semibold tracking-wide uppercase transition-colors duration-300 ${
                        isTodayChecked
                          ? "bg-emerald-500/20 text-emerald-300"
                          : "bg-primary/10 text-primary"
                      }`}
                    >
                      <Sparkles className="w-4 h-4" />
                      Today's Intention
                    </span>
                    <p
                      className={`text-2xl md:text-3xl font-medium leading-relaxed transition-all duration-300 ${
                        isTodayChecked
                          ? "line-through text-muted-foreground opacity-70"
                          : "text-foreground"
                      }`}
                    >
                      {todayGoal}
                    </p>
                  </div>

                  {/* Big check button */}
                  <button
                    onClick={() => toggleCheck(todayIndex)}
                    className={`flex-shrink-0 w-14 h-14 rounded-full border-2 flex items-center justify-center transition-all duration-300 ${
                      isTodayChecked
                        ? "bg-emerald-500 border-emerald-500 text-white scale-110 shadow-lg shadow-emerald-500/30"
                        : "border-primary/30 text-primary/30 hover:border-primary hover:text-primary hover:scale-105"
                    }`}
                    aria-label={isTodayChecked ? "Mark as incomplete" : "Mark as done"}
                  >
                    <Check className="w-7 h-7 stroke-[2.5]" />
                  </button>
                </div>

                <AnimatePresence>
                  {isTodayChecked && (
                    <motion.p
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -6 }}
                      className="text-emerald-400 font-semibold text-lg flex items-center gap-2"
                    >
                      <Check className="w-5 h-5" />
                      Goal completed! Great work today.
                    </motion.p>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </motion.div>
        ) : (
          <div className="p-8 md:p-12 text-center border-dashed border-2 border-border rounded-2xl bg-transparent flex flex-col items-center justify-center space-y-4">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center text-muted-foreground mb-2">
              <Sparkles className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-bold">No intention set for today</h2>
            <p className="text-muted-foreground max-w-md mx-auto">
              Take a moment to define the rhythm of your week. One focus per day reduces decision fatigue.
            </p>
            <Link href="/edit" className="mt-4 block">
              <Button>Set Weekly Goals</Button>
            </Link>
          </div>
        )}
      </section>

      {/* Week Overview */}
      {hasGoalsSet && weeklyData && (
        <section className="space-y-6 pt-8 border-t border-border/40">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">Your Weekly Rhythm</h2>
            <Link href="/edit" className="text-sm font-medium text-primary hover:underline flex items-center">
              Edit <ChevronRight className="w-4 h-4 ml-0.5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {weeklyData.goals.map((dayData, idx) => {
              const isToday = dayData.dayIndex === todayIndex;
              const isDone = !!checked[dayData.dayIndex];
              if (!dayData.goal && !isToday) return null;

              return (
                <motion.div
                  key={dayData.dayIndex}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: 0.05 + idx * 0.05 }}
                >
                  <div
                    className={`relative rounded-xl border p-5 flex items-start gap-4 transition-all duration-300 group ${
                      isDone
                        ? "border-emerald-500/30 bg-emerald-500/5"
                        : isToday
                        ? "border-primary/40 bg-primary/5 ring-1 ring-primary/20"
                        : "border-border bg-card hover:border-border/80"
                    }`}
                  >
                    {/* Check circle for each day */}
                    {dayData.goal && (
                      <button
                        onClick={() => toggleCheck(dayData.dayIndex)}
                        className={`mt-0.5 flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all duration-200 ${
                          isDone
                            ? "bg-emerald-500 border-emerald-500 text-white"
                            : "border-muted-foreground/30 text-transparent hover:border-primary hover:text-primary"
                        }`}
                        aria-label={isDone ? "Uncheck" : "Check off"}
                      >
                        {isDone
                          ? <Check className="w-3.5 h-3.5 stroke-[3]" />
                          : <Circle className="w-3 h-3" />
                        }
                      </button>
                    )}

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span
                          className={`text-xs font-bold uppercase tracking-wider ${
                            isDone
                              ? "text-emerald-400"
                              : isToday
                              ? "text-primary"
                              : "text-muted-foreground"
                          }`}
                        >
                          {dayData.day}
                        </span>
                        {isToday && !isDone && (
                          <span className="px-2 py-0.5 rounded-full bg-primary text-primary-foreground text-xs font-medium">
                            Today
                          </span>
                        )}
                        {isDone && (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-medium">
                            Done ✓
                          </span>
                        )}
                      </div>
                      {dayData.goal ? (
                        <p
                          className={`font-medium leading-snug transition-all duration-200 ${
                            isDone ? "line-through text-muted-foreground/60" : "text-foreground"
                          }`}
                        >
                          {dayData.goal}
                        </p>
                      ) : (
                        <p className="text-muted-foreground italic text-sm">Rest day</p>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
}
