import LanguagePracticePage from "./language-practice";
import { spanishParagraphs } from "@/data/language-paragraphs";
import { spanishWords } from "@/data/vocabulary";
import { spanishStories } from "@/data/stories";

export default function SpanishPage() {
  return (
    <LanguagePracticePage
      language="spanish"
      paragraphs={spanishParagraphs}
      words={spanishWords}
      stories={spanishStories}
      flag="🇩🇴"
      locale="es-DO"
      accentLabel="Dominican accent (es-DO)"
      accentColor="#38bdf8"
      accentColorLight="rgba(56,189,248,0.15)"
    />
  );
}
