import LanguagePracticePage from "./language-practice";
import { frenchParagraphs } from "@/data/language-paragraphs";
import { frenchWords } from "@/data/vocabulary";
import { frenchStories } from "@/data/stories";

export default function FrenchPage() {
  return (
    <LanguagePracticePage
      language="french"
      paragraphs={frenchParagraphs}
      words={frenchWords}
      stories={frenchStories}
      flag="🇫🇷"
      locale="fr-FR"
      accentLabel="France accent (fr-FR)"
      accentColor="#a78bfa"
      accentColorLight="rgba(167,139,250,0.15)"
    />
  );
}
