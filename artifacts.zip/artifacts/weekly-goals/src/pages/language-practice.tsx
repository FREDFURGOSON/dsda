import { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { Check, BookOpen, CalendarDays, ChevronLeft, Volume2, Square, Loader2, Zap } from "lucide-react";
import { Link } from "wouter";
import type { Paragraph } from "@/data/language-paragraphs";
import type { VocabWord } from "@/data/vocabulary";
import type { Story } from "@/data/stories";
import { FlashcardSection } from "@/components/flashcards";
import { StoryPlayer } from "@/components/story-player";
import { getDailyWords } from "@/data/vocabulary";
import { getDailyStory } from "@/data/stories";

interface LanguagePracticePageProps {
  language: "french" | "spanish";
  paragraphs: Paragraph[];
  words: VocabWord[];
  stories: Story[];
  flag: string;
  locale: string;
  accentLabel: string;
  accentColor: string;
  accentColorLight: string;
}

const TODAY_DATE = format(new Date(), "yyyy-MM-dd");

function getDailyParagraph(paragraphs: Paragraph[]): Paragraph {
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 1).getTime()) / 86400000
  );
  return paragraphs[dayOfYear % paragraphs.length];
}

type SpeechState = "idle" | "loading" | "speaking";

function useSpeech(locale: string, speed: number) {
  const [state, setState] = useState<SpeechState>("idle");
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    const loadVoices = () => {
      const available = window.speechSynthesis.getVoices();
      if (available.length > 0) setVoices(available);
    };
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
    return () => { window.speechSynthesis.onvoiceschanged = null; };
  }, []);

  const pickVoice = useCallback((available: SpeechSynthesisVoice[]): SpeechSynthesisVoice | null => {
    const [lang, region] = locale.split("-");
    const exact = available.find(v => v.lang.toLowerCase() === locale.toLowerCase());
    if (exact) return exact;
    const sameRegion = available.find(v => v.lang.toLowerCase().includes(locale.toLowerCase().split("-")[1]?.toLowerCase() ?? ""));
    if (sameRegion) return sameRegion;
    const sameLang = available.find(v => v.lang.toLowerCase().startsWith(lang.toLowerCase() + "-"));
    if (sameLang) return sameLang;
    return available.find(v => v.lang.toLowerCase().startsWith(lang.toLowerCase())) ?? null;
  }, [locale]);

  const speak = useCallback((text: string) => {
    window.speechSynthesis.cancel();
    setState("loading");

    const attempt = (retries = 0) => {
      const available = window.speechSynthesis.getVoices();
      const voice = pickVoice(available.length > 0 ? available : voices);

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = locale;
      utterance.rate = speed;
      utterance.pitch = 1.0;
      if (voice) utterance.voice = voice;

      utterance.onstart = () => setState("speaking");
      utterance.onend = () => setState("idle");
      utterance.onerror = (e) => {
        if (e.error === "interrupted") return;
        if (retries < 1 && available.length === 0) {
          setTimeout(() => attempt(retries + 1), 300);
        } else {
          setState("idle");
        }
      };

      utteranceRef.current = utterance;
      window.speechSynthesis.speak(utterance);
    };

    attempt();
  }, [locale, voices, pickVoice, speed]);

  const stop = useCallback(() => {
    window.speechSynthesis.cancel();
    setState("idle");
  }, []);

  return { state, speak, stop };
}

function SpeedSlider({ speed, onChange, accentColor }: { speed: number; onChange: (v: number) => void; accentColor: string }) {
  const steps = [0.5, 0.7, 0.88, 1.0, 1.2, 1.4];
  const labels: Record<number, string> = { 0.5: "0.5×", 0.7: "0.7×", 0.88: "Normal", 1.0: "1.0×", 1.2: "1.2×", 1.4: "1.4×" };

  return (
    <div className="flex items-center gap-3 flex-wrap">
      <div className="flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
        <Zap className="w-3.5 h-3.5" style={{ color: accentColor }} />
        Voice Speed
      </div>
      <div className="flex items-center gap-1">
        {steps.map(s => (
          <button
            key={s}
            onClick={() => onChange(s)}
            className="px-2.5 py-1 rounded-full text-[11px] font-semibold transition-all duration-150 active:scale-95"
            style={
              speed === s
                ? { background: accentColor, color: "#fff" }
                : { background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.5)", border: "1px solid rgba(255,255,255,0.1)" }
            }
          >
            {labels[s]}
          </button>
        ))}
      </div>
    </div>
  );
}

export default function LanguagePracticePage({
  language,
  paragraphs,
  words,
  stories,
  flag,
  locale,
  accentLabel,
  accentColor,
  accentColorLight,
}: LanguagePracticePageProps) {
  const dailyWords = getDailyWords(words ?? [], 15);
  const dailyStory = getDailyStory(stories);
  const storageKey = `rhythm-lang-checked-${language}-${TODAY_DATE}`;
  const speedKey = `rhythm-speed-${language}`;

  const [isChecked, setIsChecked] = useState(() => {
    try { return localStorage.getItem(storageKey) === "true"; } catch { return false; }
  });
  const [showTranslation, setShowTranslation] = useState(false);
  const [speed, setSpeed] = useState<number>(() => {
    try { return Number(localStorage.getItem(speedKey)) || 0.88; } catch { return 0.88; }
  });

  const { state: speechState, speak, stop } = useSpeech(locale, speed);

  useEffect(() => {
    try { localStorage.setItem(storageKey, String(isChecked)); } catch {}
    if (isChecked) {
      fetch("/api/streaks/check-in", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ language }),
      }).catch(() => {});
    }
  }, [isChecked, storageKey, language]);

  useEffect(() => {
    try { localStorage.setItem(speedKey, String(speed)); } catch {}
    // Cancel any playing speech when speed changes
    window.speechSynthesis?.cancel();
  }, [speed, speedKey]);

  // Stop speech when navigating away
  useEffect(() => () => { window.speechSynthesis?.cancel(); }, []);

  const paragraph = getDailyParagraph(paragraphs);
  const currentDate = format(new Date(), "EEEE, MMMM do yyyy");
  const langLabel = language === "french" ? "French" : "Spanish";
  const practicedLabel = language === "french" ? "Lu et compris !" : "¡Leído y entendido!";
  const isSpeaking = speechState === "speaking";
  const isLoading = speechState === "loading";

  return (
    <div className="max-w-2xl mx-auto pb-16 space-y-8">
      {/* Back link */}
      <Link
        href="/"
        className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors group"
      >
        <ChevronLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
        Back to home
      </Link>

      {/* Header */}
      <div className="flex items-center gap-3">
        <span className="text-4xl">{flag}</span>
        <div>
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight">
            Daily {langLabel}
          </h1>
          <p className="text-muted-foreground flex items-center gap-1.5 mt-0.5">
            <CalendarDays className="w-4 h-4" />
            {currentDate}
          </p>
        </div>
      </div>

      {/* Speed slider — shared across all TTS on this page */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
        className="rounded-xl border border-border/40 px-5 py-3.5"
        style={{ background: "rgba(255,255,255,0.025)" }}
      >
        <SpeedSlider speed={speed} onChange={setSpeed} accentColor={accentColor} />
      </motion.div>

      {/* Topic badge + accent label */}
      <div className="flex items-center gap-3 flex-wrap">
        <span
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-semibold uppercase tracking-wider"
          style={{ background: accentColorLight, color: accentColor }}
        >
          <BookOpen className="w-4 h-4" />
          {paragraph.topic}
        </span>
        <span className="text-xs text-muted-foreground font-medium px-2 py-1 rounded-full border border-border/50">
          🎙 {accentLabel}
        </span>
      </div>

      {/* Foreign paragraph card */}
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, ease: [0.23, 1, 0.32, 1] }}
      >
        <div
          className="relative rounded-2xl border p-7 md:p-10 space-y-5 transition-all duration-500"
          style={{
            borderColor: isChecked ? "rgba(52,211,153,0.4)" : isSpeaking ? `${accentColor}55` : "rgba(255,255,255,0.08)",
            background: isChecked
              ? "rgba(52,211,153,0.07)"
              : isSpeaking
              ? `${accentColor}08`
              : "rgba(255,255,255,0.03)",
          }}
        >
          {/* Accent left bar */}
          <div
            className="absolute top-0 left-0 w-1 h-full rounded-l-2xl transition-colors duration-500"
            style={{ background: isChecked ? "#34d399" : isSpeaking ? accentColor : `${accentColor}80` }}
          />

          {/* Top row: language label + listen button */}
          <div className="flex items-center justify-between gap-4">
            <div
              className="text-xs font-bold uppercase tracking-widest"
              style={{ color: isChecked ? "#34d399" : accentColor }}
            >
              {langLabel}
            </div>

            <button
              onClick={() => isSpeaking || isLoading ? stop() : speak(paragraph.foreign)}
              className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold transition-all duration-200 active:scale-95"
              style={
                isSpeaking
                  ? { background: `${accentColor}22`, color: accentColor, border: `1.5px solid ${accentColor}66` }
                  : { background: "rgba(255,255,255,0.06)", color: "var(--color-muted-foreground)", border: "1.5px solid rgba(255,255,255,0.1)" }
              }
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : isSpeaking ? (
                <>
                  <Square className="w-3.5 h-3.5 fill-current" />
                  <span>Stop</span>
                  <span className="flex items-end gap-0.5 h-4">
                    {[0, 0.15, 0.3].map((delay, i) => (
                      <span
                        key={i}
                        className="w-0.5 rounded-full animate-bounce"
                        style={{
                          height: `${10 + i * 4}px`,
                          background: accentColor,
                          animationDelay: `${delay}s`,
                          animationDuration: "0.6s",
                        }}
                      />
                    ))}
                  </span>
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4" />
                  <span>Listen</span>
                </>
              )}
            </button>
          </div>

          {/* The paragraph text */}
          <p
            className="text-lg md:text-xl leading-relaxed font-medium text-foreground"
            lang={language === "french" ? "fr" : "es"}
          >
            {paragraph.foreign}
          </p>

          {/* Show translation toggle */}
          <div className="pt-2 border-t border-border/40">
            <button
              onClick={() => setShowTranslation(v => !v)}
              className="text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors underline underline-offset-4"
            >
              {showTranslation ? "Hide translation" : "Show English translation"}
            </button>

            <AnimatePresence>
              {showTranslation && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                  className="overflow-hidden"
                >
                  <div className="mt-4 pt-4 border-t border-border/30">
                    <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-3">
                      English Translation
                    </p>
                    <p className="text-base md:text-lg leading-relaxed text-muted-foreground italic">
                      {paragraph.english}
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </motion.div>

      {/* Story Player — Pimsleur-style progressive lesson */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, delay: 0.1, ease: [0.23, 1, 0.32, 1] }}
        className="rounded-2xl border p-7 md:p-8 space-y-6"
        style={{ borderColor: "rgba(255,255,255,0.07)", background: "rgba(255,255,255,0.02)" }}
      >
        <StoryPlayer
          story={dailyStory}
          locale={locale}
          accentColor={accentColor}
          accentColorLight={accentColorLight}
          speed={speed}
        />
      </motion.div>

      {/* Flashcard vocabulary section */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, delay: 0.2, ease: [0.23, 1, 0.32, 1] }}
        className="rounded-2xl border p-7 md:p-8 space-y-6"
        style={{ borderColor: "rgba(255,255,255,0.07)", background: "rgba(255,255,255,0.02)" }}
      >
        <FlashcardSection
          words={dailyWords}
          locale={locale}
          accentColor={accentColor}
          accentColorLight={accentColorLight}
          speed={speed}
        />
      </motion.div>

      {/* Complete button */}
      <div className="flex flex-col items-center gap-4 pt-2">
        <button
          onClick={() => setIsChecked(v => !v)}
          className={`w-full max-w-sm py-4 px-8 rounded-2xl font-bold text-lg flex items-center justify-center gap-3 transition-all duration-300 ${
            isChecked
              ? "bg-emerald-500 text-white shadow-lg shadow-emerald-500/30 scale-[1.02]"
              : "border-2 border-dashed border-border text-muted-foreground hover:border-primary hover:text-foreground"
          }`}
        >
          <div
            className={`w-7 h-7 rounded-full border-2 flex items-center justify-center transition-all duration-200 ${
              isChecked ? "bg-white border-white text-emerald-500" : "border-current"
            }`}
          >
            <Check className="w-4 h-4 stroke-[3]" />
          </div>
          {isChecked ? practicedLabel : `Mark today's ${langLabel} as done`}
        </button>

        <AnimatePresence>
          {isChecked && (
            <motion.p
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="text-emerald-400 text-sm font-medium text-center"
            >
              ✨ Great job! Come back tomorrow for a new lesson.
            </motion.p>
          )}
        </AnimatePresence>
      </div>

      {/* Tips */}
      <div className="rounded-xl border border-border/50 bg-muted/20 p-5 space-y-2">
        <p className="text-sm font-semibold text-foreground">💡 Practice Tips</p>
        <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
          <li>Use the <strong className="text-foreground">speed buttons</strong> to slow down or speed up all voice playback</li>
          <li>Press <strong className="text-foreground">▶ Play</strong> in the story to hear a full guided lesson</li>
          <li>Repeat phrases out loud — speaking is as important as listening</li>
          <li>Tap flashcards to reveal translations, then listen to the pronunciation</li>
          <li>A fresh paragraph and lesson appear every day — keep the streak going!</li>
        </ul>
      </div>
    </div>
  );
}
