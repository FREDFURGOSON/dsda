import { useEffect } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Save, ArrowLeft } from "lucide-react";

import { 
  useGetWeeklyGoals, 
  useSetWeeklyGoals, 
  getGetWeeklyGoalsQueryKey,
  getGetTodayGoalQueryKey
} from "@workspace/api-client-react";
import { Button, Card, Textarea } from "@/components/ui-elements";

const formSchema = z.object({
  goals: z.array(z.string()).length(7)
});

type FormValues = z.infer<typeof formSchema>;

const DAYS_OF_WEEK = [
  "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
];

export default function EditGoals() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  
  const { data: weeklyData, isLoading: isLoadingData } = useGetWeeklyGoals();
  const { mutate: saveGoals, isPending: isSaving } = useSetWeeklyGoals();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      goals: Array(7).fill("")
    }
  });

  useEffect(() => {
    if (weeklyData?.goals) {
      const initialGoals = Array(7).fill("");
      weeklyData.goals.forEach(g => {
        if (g.dayIndex >= 0 && g.dayIndex < 7) {
          initialGoals[g.dayIndex] = g.goal || "";
        }
      });
      form.reset({ goals: initialGoals });
    }
  }, [weeklyData, form]);

  const onSubmit = (values: FormValues) => {
    saveGoals({ data: { goals: values.goals } }, {
      onSuccess: () => {
        // Invalidate queries so the home page refetches
        queryClient.invalidateQueries({ queryKey: getGetWeeklyGoalsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetTodayGoalQueryKey() });
        setLocation("/");
      }
    });
  };

  if (isLoadingData) {
    return (
      <div className="space-y-6 max-w-2xl mx-auto animate-pulse">
        <div className="h-10 w-48 bg-muted rounded-lg" />
        <div className="space-y-4">
          {[1, 2, 3, 4, 5, 6, 7].map(i => (
            <Card key={i} className="h-32 bg-muted/50" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto pb-24">
      <div className="mb-8 space-y-4">
        <button 
          onClick={() => setLocation("/")}
          className="group flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          Back to today
        </button>
        <div className="space-y-2">
          <h1 className="text-3xl md:text-4xl font-bold font-display">Define Your Rhythm</h1>
          <p className="text-muted-foreground text-lg">
            Set one core intention for each day of the week. This loops continuously.
          </p>
        </div>
      </div>

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="space-y-5">
          {DAYS_OF_WEEK.map((day, index) => (
            <motion.div
              key={day}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05, duration: 0.3 }}
            >
              <Card className="p-1 focus-within:ring-2 focus-within:ring-primary/50 focus-within:border-primary transition-all duration-300">
                <div className="px-4 pt-3 pb-1">
                  <label 
                    htmlFor={`goal-${index}`} 
                    className="text-sm font-bold uppercase tracking-wider text-muted-foreground"
                  >
                    {day}
                  </label>
                </div>
                <Textarea
                  id={`goal-${index}`}
                  {...form.register(`goals.${index}`)}
                  placeholder={`What's your focus every ${day}?`}
                  className="border-0 shadow-none focus:ring-0 bg-transparent text-base md:text-lg rounded-t-none resize-none min-h-[80px]"
                />
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Sticky Save Button footer */}
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-background/80 backdrop-blur-xl border-t border-border z-10 sm:relative sm:bg-transparent sm:border-0 sm:backdrop-blur-none sm:p-0 mt-8">
          <div className="max-w-2xl mx-auto flex justify-end">
            <Button 
              type="submit" 
              isLoading={isSaving} 
              className="w-full sm:w-auto text-lg px-8 py-6 sm:py-3 shadow-2xl"
            >
              <Save className="w-5 h-5 mr-2" />
              Save Routine
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
