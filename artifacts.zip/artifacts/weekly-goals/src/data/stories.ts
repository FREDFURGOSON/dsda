export interface StorySegment {
  type: "intro" | "phrase" | "dialogue" | "story" | "practice" | "tip";
  english: string;
  foreign?: string;
  prompt?: string;
}

export interface Story {
  title: string;
  nativeTitle: string;
  difficulty: 1 | 2 | 3 | 4 | 5;
  estimatedMinutes: number;
  theme: string;
  segments: StorySegment[];
}

// ─────────────────────────────────────────────────────────────────────────────
// FRENCH STORIES  (14 lessons, cycling daily, easiest → hardest)
// ─────────────────────────────────────────────────────────────────────────────
export const frenchStories: Story[] = [
  {
    title: "First Greetings",
    nativeTitle: "Les premières salutations",
    difficulty: 1,
    estimatedMinutes: 12,
    theme: "Greetings & basic politeness",
    segments: [
      {
        type: "intro",
        english: "Welcome to your first French lesson. Today you will learn the most essential greetings and polite expressions. Listen to each phrase, then try to repeat it out loud before moving on. The goal is not perfection — it is familiarity. Let's begin.",
      },
      {
        type: "phrase",
        foreign: "Bonjour !",
        english: "Hello! / Good day!",
        prompt: "Used any time of day, but especially in the morning and afternoon. Say it now.",
      },
      {
        type: "phrase",
        foreign: "Bonsoir !",
        english: "Good evening!",
        prompt: "Used from the late afternoon onward. Repeat: Bonsoir.",
      },
      {
        type: "phrase",
        foreign: "Au revoir !",
        english: "Goodbye!",
        prompt: "The classic farewell. Say it aloud: Au revoir.",
      },
      {
        type: "phrase",
        foreign: "S'il vous plaît.",
        english: "Please. (formal)",
        prompt: "Polite and essential. Repeat: S'il vous plaît.",
      },
      {
        type: "phrase",
        foreign: "Merci beaucoup !",
        english: "Thank you very much!",
        prompt: "You will use this every day. Repeat: Merci beaucoup.",
      },
      {
        type: "story",
        foreign: "Paul entre dans une boulangerie le matin. Il voit la boulangère et dit : « Bonjour madame ! » La boulangère répond avec le sourire : « Bonjour monsieur ! »",
        english: "Paul enters a bakery in the morning. He sees the baker and says: 'Hello madam!' The baker replies with a smile: 'Hello sir!'",
      },
      {
        type: "dialogue",
        foreign: "— Bonjour ! Comment allez-vous ?\n— Très bien, merci. Et vous ?\n— Bien aussi, merci.",
        english: "— Hello! How are you?\n— Very well, thank you. And you?\n— Well too, thank you.",
        prompt: "This is the classic greeting exchange. Listen, then try to say Paul's first line.",
      },
      {
        type: "practice",
        foreign: "Bonjour ! Comment allez-vous ?",
        english: "Hello! How are you?",
        prompt: "Now it's your turn. Say this phrase aloud as naturally as you can.",
      },
      {
        type: "tip",
        english: "In French, 'Bonjour' literally means 'Good day'. Always use it when entering a shop or greeting someone — it is considered rude not to. The French take greetings very seriously!",
      },
      {
        type: "phrase",
        foreign: "Excusez-moi.",
        english: "Excuse me.",
        prompt: "Used to get someone's attention or to apologise gently. Repeat: Excusez-moi.",
      },
      {
        type: "practice",
        foreign: "Merci beaucoup, au revoir !",
        english: "Thank you very much, goodbye!",
        prompt: "Your exit line from any shop or encounter. Say it with confidence.",
      },
    ],
  },
  {
    title: "At the Bakery",
    nativeTitle: "À la boulangerie",
    difficulty: 1,
    estimatedMinutes: 13,
    theme: "Shopping & numbers 1–10",
    segments: [
      {
        type: "intro",
        english: "Today's story takes place at a classic French bakery. You will learn how to order bread, ask for a price, and use numbers one to ten. Every lesson builds on the last — you already know your greetings. Now let's go shopping.",
      },
      {
        type: "phrase",
        foreign: "Je voudrais une baguette, s'il vous plaît.",
        english: "I would like a baguette, please.",
        prompt: "This is how you order politely. Listen and repeat: Je voudrais...",
      },
      {
        type: "phrase",
        foreign: "C'est combien ?",
        english: "How much is it?",
        prompt: "Essential for any purchase. Repeat: C'est combien ?",
      },
      {
        type: "phrase",
        foreign: "Un, deux, trois, quatre, cinq, six, sept, huit, neuf, dix.",
        english: "One, two, three, four, five, six, seven, eight, nine, ten.",
        prompt: "Learn these numbers — you will need them for prices and quantities. Repeat them slowly.",
      },
      {
        type: "story",
        foreign: "Sophie entre dans la boulangerie. Elle dit bonjour à la boulangère. Elle demande : « Je voudrais deux croissants et une baguette, s'il vous plaît. » La boulangère répond : « Ça fait trois euros cinquante. » Sophie donne un billet de cinq euros et reçoit la monnaie.",
        english: "Sophie enters the bakery. She greets the baker. She asks: 'I would like two croissants and a baguette, please.' The baker replies: 'That comes to three euros fifty.' Sophie gives a five-euro note and receives her change.",
      },
      {
        type: "dialogue",
        foreign: "— Bonjour madame ! Je voudrais trois croissants, s'il vous plaît.\n— Bien sûr. C'est deux euros vingt.\n— Voilà. Merci beaucoup !\n— De rien. Bonne journée !",
        english: "— Hello madam! I would like three croissants, please.\n— Of course. That's two euros twenty.\n— Here you are. Thank you very much!\n— You're welcome. Have a good day!",
        prompt: "Notice 'De rien' — 'You're welcome'. And 'Bonne journée' — 'Have a good day'. Listen, then repeat the customer's lines.",
      },
      {
        type: "practice",
        foreign: "Je voudrais une baguette et deux croissants, s'il vous plaît.",
        english: "I would like a baguette and two croissants, please.",
        prompt: "Say this order as if you are standing at the counter right now.",
      },
      {
        type: "tip",
        english: "In France, saying 'Bonjour' when you walk into a shop is not optional — it is expected. The baker will likely say it first. Always respond in kind. Skipping the greeting is considered very impolite.",
      },
      {
        type: "phrase",
        foreign: "Bonne journée !",
        english: "Have a good day!",
        prompt: "Said when leaving. Repeat: Bonne journée. The reply is also 'Bonne journée' or 'Vous aussi' — you too.",
      },
      {
        type: "practice",
        foreign: "C'est combien ? — Deux euros, s'il vous plaît. — Voilà, merci !",
        english: "How much is it? — Two euros, please. — Here you are, thank you!",
        prompt: "Read through this mini-exchange aloud, playing both roles.",
      },
    ],
  },
  {
    title: "Introducing Yourself",
    nativeTitle: "Se présenter",
    difficulty: 2,
    estimatedMinutes: 14,
    theme: "Names, nationality & basic description",
    segments: [
      {
        type: "intro",
        english: "In this lesson you will learn how to introduce yourself in French — your name, where you are from, your age, and what you do. These are the building blocks of every conversation. You already know how to say hello — now let's go further.",
      },
      {
        type: "phrase",
        foreign: "Je m'appelle Claire.",
        english: "My name is Claire.",
        prompt: "Replace 'Claire' with your own name. Repeat: Je m'appelle...",
      },
      {
        type: "phrase",
        foreign: "J'ai vingt-cinq ans.",
        english: "I am twenty-five years old.",
        prompt: "In French, you literally say 'I have twenty-five years'. Try it with your own age.",
      },
      {
        type: "phrase",
        foreign: "Je suis américain. / Je suis américaine.",
        english: "I am American. (male / female)",
        prompt: "In French, adjectives change depending on your gender. The feminine adds an -e at the end.",
      },
      {
        type: "phrase",
        foreign: "J'habite à New York.",
        english: "I live in New York.",
        prompt: "Replace 'New York' with your city. Repeat: J'habite à...",
      },
      {
        type: "story",
        foreign: "Lucas est un jeune étudiant français. Il a vingt-deux ans et il habite à Lyon. Il étudie l'anglais à l'université. Aujourd'hui, il rencontre Emma, une étudiante américaine. Elle s'appelle Emma, elle a vingt ans et elle vient de Boston.",
        english: "Lucas is a young French student. He is twenty-two and lives in Lyon. He studies English at university. Today he meets Emma, an American student. Her name is Emma, she is twenty and comes from Boston.",
      },
      {
        type: "dialogue",
        foreign: "— Bonjour ! Je m'appelle Lucas. Et toi ?\n— Bonjour ! Moi, c'est Emma. Je suis américaine.\n— Ah, tu parles très bien français !\n— Merci ! J'apprends depuis six mois.",
        english: "— Hello! My name is Lucas. And you?\n— Hello! I'm Emma. I'm American.\n— Ah, you speak French very well!\n— Thank you! I've been learning for six months.",
        prompt: "Notice 'tu parles' — the informal 'you speak'. We use 'tu' with friends and peers. Listen and repeat Emma's lines.",
      },
      {
        type: "tip",
        english: "French has two words for 'you' — 'tu' (informal, used with friends, family, children) and 'vous' (formal, used with strangers, elders, or groups). When in doubt, use 'vous'. It is always polite.",
      },
      {
        type: "practice",
        foreign: "Je m'appelle... J'ai... ans. J'habite à... Je suis...",
        english: "My name is... I am... years old. I live in... I am...",
        prompt: "Fill in the blanks with your own information and say your full introduction aloud.",
      },
      {
        type: "phrase",
        foreign: "Enchanté(e) !",
        english: "Pleased to meet you!",
        prompt: "Said when you first meet someone. Males say 'Enchanté', females say 'Enchantée'. Both are pronounced the same.",
      },
      {
        type: "practice",
        foreign: "Je m'appelle Emma. J'habite à Boston. Je suis américaine. Enchanté !",
        english: "My name is Emma. I live in Boston. I am American. Pleased to meet you!",
        prompt: "Say this complete introduction naturally and with confidence.",
      },
    ],
  },
  {
    title: "Numbers and Time",
    nativeTitle: "Les chiffres et l'heure",
    difficulty: 2,
    estimatedMinutes: 14,
    theme: "Telling the time, days of the week",
    segments: [
      {
        type: "intro",
        english: "Time is everything. In this lesson you will learn to tell the time in French, say the days of the week, and understand basic time expressions. By the end, you will be able to make and understand simple appointments.",
      },
      {
        type: "phrase",
        foreign: "Quelle heure est-il ?",
        english: "What time is it?",
        prompt: "Repeat this question clearly: Quelle heure est-il ?",
      },
      {
        type: "phrase",
        foreign: "Il est huit heures. Il est midi. Il est minuit.",
        english: "It is eight o'clock. It is noon. It is midnight.",
        prompt: "The structure is 'Il est + number + heures'. Repeat each one.",
      },
      {
        type: "phrase",
        foreign: "Lundi, mardi, mercredi, jeudi, vendredi, samedi, dimanche.",
        english: "Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday.",
        prompt: "Days of the week are not capitalised in French. Repeat them all slowly.",
      },
      {
        type: "story",
        foreign: "Chaque matin, Marie se lève à sept heures. Elle prend son café à sept heures et demie. Elle part au travail à huit heures moins le quart. Son rendez-vous avec le médecin est lundi à dix heures trente.",
        english: "Every morning, Marie gets up at seven o'clock. She has her coffee at half past seven. She leaves for work at quarter to eight. Her appointment with the doctor is Monday at ten thirty.",
      },
      {
        type: "dialogue",
        foreign: "— Excusez-moi, quelle heure est-il ?\n— Il est quatorze heures trente.\n— Oh, j'ai rendez-vous à quinze heures ! Je dois partir. Merci !\n— De rien. Bonne chance !",
        english: "— Excuse me, what time is it?\n— It is fourteen thirty (2:30 PM).\n— Oh, I have an appointment at fifteen hundred! I have to go. Thank you!\n— You're welcome. Good luck!",
        prompt: "France uses the 24-hour clock in formal contexts. 14h30 = 2:30 PM. Listen and repeat the first person's lines.",
      },
      {
        type: "tip",
        english: "In French, half past is 'et demie' (e.g. huit heures et demie), quarter past is 'et quart', and quarter to is 'moins le quart'. Noon is 'midi' and midnight is 'minuit'. These are used very frequently.",
      },
      {
        type: "phrase",
        foreign: "Aujourd'hui, demain, hier. Ce matin, cet après-midi, ce soir.",
        english: "Today, tomorrow, yesterday. This morning, this afternoon, this evening.",
        prompt: "Repeat these time words — they will appear constantly in conversation.",
      },
      {
        type: "practice",
        foreign: "Il est neuf heures et quart. Mon rendez-vous est mercredi à quinze heures.",
        english: "It is quarter past nine. My appointment is Wednesday at three o'clock.",
        prompt: "Say both sentences aloud, focusing on the time expressions.",
      },
    ],
  },
  {
    title: "The Family",
    nativeTitle: "La famille",
    difficulty: 2,
    estimatedMinutes: 13,
    theme: "Family members & possessives",
    segments: [
      {
        type: "intro",
        english: "Family is a central topic in every language. Today you will learn the French words for family members and how to use simple possessive words like 'my', 'your', and 'his'. You will also hear a short family story.",
      },
      {
        type: "phrase",
        foreign: "Mon père, ma mère, mon frère, ma sœur.",
        english: "My father, my mother, my brother, my sister.",
        prompt: "Notice 'mon' for masculine and 'ma' for feminine — like 'my' but gendered. Repeat all four.",
      },
      {
        type: "phrase",
        foreign: "Mon grand-père, ma grand-mère, mon oncle, ma tante.",
        english: "My grandfather, my grandmother, my uncle, my aunt.",
        prompt: "Repeat each family member clearly.",
      },
      {
        type: "phrase",
        foreign: "J'ai un frère et deux sœurs.",
        english: "I have one brother and two sisters.",
        prompt: "Adapt this to your own family. How many brothers or sisters do you have?",
      },
      {
        type: "story",
        foreign: "La famille Dupont est grande. Le père s'appelle Michel et la mère s'appelle Isabelle. Ils ont trois enfants : un fils et deux filles. Le fils s'appelle Antoine, il a seize ans. Les filles s'appellent Lucie et Chloé, elles ont douze et neuf ans. Les grands-parents habitent dans le sud de la France.",
        english: "The Dupont family is large. The father's name is Michel and the mother's name is Isabelle. They have three children: one son and two daughters. The son's name is Antoine, he is sixteen. The daughters are called Lucie and Chloé, they are twelve and nine. The grandparents live in the south of France.",
      },
      {
        type: "dialogue",
        foreign: "— Tu as des frères et sœurs ?\n— Oui, j'ai une sœur. Elle s'appelle Marie. Elle a vingt ans.\n— Et tes parents ? Ils habitent où ?\n— Ils habitent à Bordeaux. Et toi ?",
        english: "— Do you have brothers and sisters?\n— Yes, I have one sister. Her name is Marie. She is twenty.\n— And your parents? Where do they live?\n— They live in Bordeaux. And you?",
        prompt: "Listen carefully to the question forms. Then try to answer: 'Tu as des frères et sœurs ?' — answer with your own family.",
      },
      {
        type: "tip",
        english: "In French, 'son' and 'sa' mean 'his' or 'her' — the gender follows the noun, not the person. So 'his sister' is 'sa sœur' and 'her brother' is 'son frère'. This can be confusing at first, but you'll get used to it.",
      },
      {
        type: "practice",
        foreign: "Dans ma famille, il y a... personnes. J'ai... Je n'ai pas de...",
        english: "In my family, there are... people. I have... I don't have any...",
        prompt: "Describe your own family aloud using what you've learned today.",
      },
    ],
  },
  {
    title: "At the Café",
    nativeTitle: "Au café",
    difficulty: 2,
    estimatedMinutes: 14,
    theme: "Ordering drinks, expressing preferences",
    segments: [
      {
        type: "intro",
        english: "The French café is a social institution. Today you learn to order drinks, ask for the bill, and express what you like or don't like. You'll also pick up the critical phrase 'je voudrais' — 'I would like' — which is far more polite than simply saying 'I want'.",
      },
      {
        type: "phrase",
        foreign: "Je voudrais un café, s'il vous plaît.",
        english: "I would like a coffee, please.",
        prompt: "Repeat: Je voudrais un café.",
      },
      {
        type: "phrase",
        foreign: "Un thé, un jus d'orange, une eau minérale, une bière.",
        english: "A tea, an orange juice, a mineral water, a beer.",
        prompt: "Learn these common drinks. Repeat each one.",
      },
      {
        type: "phrase",
        foreign: "J'aime le café. Je n'aime pas le thé.",
        english: "I like coffee. I don't like tea.",
        prompt: "To negate in French, wrap the verb: ne...pas. Repeat both sentences.",
      },
      {
        type: "story",
        foreign: "Thomas s'assoit à la terrasse d'un café parisien. Le serveur arrive. Thomas commande un café et un croissant. Il lit son journal au soleil. C'est un moment de bonheur simple, typiquement français.",
        english: "Thomas sits on the terrace of a Parisian café. The waiter arrives. Thomas orders a coffee and a croissant. He reads his newspaper in the sun. It is a moment of simple happiness, typically French.",
      },
      {
        type: "dialogue",
        foreign: "— Bonjour monsieur, que désirez-vous ?\n— Je voudrais un café et un croissant, s'il vous plaît.\n— Bien sûr. Vous voulez du sucre ?\n— Non merci, je le prends sans sucre.\n— D'accord. Je vous apporte ça tout de suite.",
        english: "— Good morning sir, what would you like?\n— I would like a coffee and a croissant, please.\n— Of course. Would you like sugar?\n— No thank you, I take it without sugar.\n— Alright. I'll bring that right away.",
        prompt: "Listen to the exchange. Then repeat Thomas's lines: 'Je voudrais un café et un croissant...'",
      },
      {
        type: "phrase",
        foreign: "L'addition, s'il vous plaît !",
        english: "The bill, please!",
        prompt: "Essential! Say it with a raised hand: L'addition, s'il vous plaît.",
      },
      {
        type: "tip",
        english: "In France, the waiter will NOT bring you the bill until you ask for it. Leaving money on the table and walking out is not the custom. Always ask: 'L'addition, s'il vous plaît.' Tipping is appreciated but not mandatory — 10% is generous.",
      },
      {
        type: "practice",
        foreign: "Bonjour ! Je voudrais un thé et une eau minérale, s'il vous plaît. L'addition, s'il vous plaît !",
        english: "Hello! I would like a tea and a mineral water, please. The bill, please!",
        prompt: "Say this full café interaction aloud, as naturally as possible.",
      },
    ],
  },
  {
    title: "Around Town",
    nativeTitle: "En ville",
    difficulty: 3,
    estimatedMinutes: 15,
    theme: "Places in the city, asking where things are",
    segments: [
      {
        type: "intro",
        english: "You're now walking through a French city. Today you'll learn the names of important places and how to ask where something is. This lesson introduces 'où est' — 'where is' — and some essential prepositions.",
      },
      {
        type: "phrase",
        foreign: "Où est la gare, s'il vous plaît ?",
        english: "Where is the train station, please?",
        prompt: "Repeat: Où est la gare ?",
      },
      {
        type: "phrase",
        foreign: "La banque, la pharmacie, le supermarché, l'hôpital, la mairie.",
        english: "The bank, the pharmacy, the supermarket, the hospital, the town hall.",
        prompt: "These are the essential city places. Repeat each one.",
      },
      {
        type: "phrase",
        foreign: "C'est à gauche. C'est à droite. C'est tout droit. C'est près d'ici.",
        english: "It's on the left. It's on the right. It's straight ahead. It's nearby.",
        prompt: "Direction vocabulary. Repeat each phrase clearly.",
      },
      {
        type: "story",
        foreign: "Amélie est nouvelle en ville. Elle cherche la pharmacie. Elle s'arrête devant un homme âgé et demande : « Excusez-moi, où est la pharmacie ? » L'homme sourit et répond : « C'est simple ! Allez tout droit, tournez à gauche au feu, et c'est la troisième rue à droite. »",
        english: "Amélie is new in town. She's looking for the pharmacy. She stops in front of an elderly man and asks: 'Excuse me, where is the pharmacy?' The man smiles and replies: 'It's simple! Go straight ahead, turn left at the traffic light, and it's the third street on the right.'",
      },
      {
        type: "dialogue",
        foreign: "— Pardon madame, il y a un supermarché près d'ici ?\n— Oui, il y en a un rue Victor Hugo, à cinq minutes à pied.\n— C'est loin ?\n— Non, c'est tout près. Traversez la place et c'est à droite.\n— Merci infiniment !",
        english: "— Excuse me madam, is there a supermarket nearby?\n— Yes, there is one on Victor Hugo Street, five minutes on foot.\n— Is it far?\n— No, it's very close. Cross the square and it's on the right.\n— Thank you so much!",
        prompt: "Listen for 'il y a' — 'there is / there are'. This is extremely common. Repeat the question: 'Il y a un supermarché près d'ici ?'",
      },
      {
        type: "tip",
        english: "'Il y a' is one of the most versatile phrases in French. It means 'there is' or 'there are', but also 'ago' when talking about time (e.g. il y a deux ans — two years ago). Master it early.",
      },
      {
        type: "practice",
        foreign: "Excusez-moi, où est la gare ? — C'est tout droit, puis à gauche.",
        english: "Excuse me, where is the train station? — It's straight ahead, then left.",
        prompt: "Play both roles in this short exchange. Speak both lines aloud.",
      },
    ],
  },
  {
    title: "At the Market",
    nativeTitle: "Au marché",
    difficulty: 3,
    estimatedMinutes: 15,
    theme: "Quantities, food, and bargaining",
    segments: [
      {
        type: "intro",
        english: "Today you're at a vibrant French market. You will learn how to ask for quantities, name common fruits and vegetables, and handle a real shopping conversation. This lesson introduces partitive articles — the French way of saying 'some'.",
      },
      {
        type: "phrase",
        foreign: "Je voudrais du pain, de la confiture, des pommes.",
        english: "I would like some bread, some jam, some apples.",
        prompt: "'Du' (masculine), 'de la' (feminine), 'des' (plural) all mean 'some'. Repeat: du pain, de la confiture, des pommes.",
      },
      {
        type: "phrase",
        foreign: "Un kilo de tomates. Deux cents grammes de fromage. Une bouteille d'eau.",
        english: "One kilo of tomatoes. Two hundred grams of cheese. One bottle of water.",
        prompt: "Quantities are essential at markets. Repeat each measurement phrase.",
      },
      {
        type: "story",
        foreign: "Chaque samedi matin, Julien va au marché du village. Il achète des légumes frais : des carottes, des courgettes et de la laitue. Chez le fromager, il prend deux cents grammes de camembert. Il dépense environ quinze euros en tout. Pour lui, c'est le meilleur moment de la semaine.",
        english: "Every Saturday morning, Julien goes to the village market. He buys fresh vegetables: carrots, courgettes and lettuce. At the cheesemonger, he gets two hundred grams of camembert. He spends about fifteen euros in total. For him, it is the best moment of the week.",
      },
      {
        type: "dialogue",
        foreign: "— Bonjour ! Qu'est-ce qu'il vous faut ?\n— Je voudrais un kilo de pommes et une livre de cerises, s'il vous plaît.\n— Voilà ! C'est tout ?\n— Non, donnez-moi aussi cinq cents grammes de fraises.\n— Bien. Ça fait sept euros quarante.",
        english: "— Hello! What do you need?\n— I would like a kilo of apples and a pound of cherries, please.\n— Here you go! Is that all?\n— No, also give me five hundred grams of strawberries.\n— Right. That comes to seven euros forty.",
        prompt: "Notice 'Qu'est-ce qu'il vous faut ?' — 'What do you need?' A classic market opening. Repeat the customer's lines.",
      },
      {
        type: "tip",
        english: "In France, a 'livre' at the market traditionally means 500 grams, not the British pound (454g). Don't be surprised when asking for 'une livre de fromage' — you'll get half a kilo. The metric system rules.",
      },
      {
        type: "practice",
        foreign: "Je voudrais un kilo de tomates, deux cents grammes de beurre et une bouteille d'huile d'olive.",
        english: "I would like a kilo of tomatoes, two hundred grams of butter, and a bottle of olive oil.",
        prompt: "Read this shopping list aloud as if you're at the counter.",
      },
    ],
  },
  {
    title: "Asking Directions",
    nativeTitle: "Demander son chemin",
    difficulty: 3,
    estimatedMinutes: 15,
    theme: "Giving and following directions",
    segments: [
      {
        type: "intro",
        english: "You've taken the metro and now you're lost on a Parisian street. Today's lesson focuses entirely on asking for and understanding directions. You'll learn imperative verb forms — the command form — which are used when giving directions.",
      },
      {
        type: "phrase",
        foreign: "Tournez à gauche. Tournez à droite. Continuez tout droit. Prenez la première rue à gauche.",
        english: "Turn left. Turn right. Continue straight ahead. Take the first street on the left.",
        prompt: "These are imperative forms — commands. Repeat each one.",
      },
      {
        type: "phrase",
        foreign: "C'est au bout de la rue. C'est en face de la mairie. C'est à côté de la pharmacie.",
        english: "It's at the end of the street. It's opposite the town hall. It's next to the pharmacy.",
        prompt: "Prepositions of place are very useful here. Repeat each phrase.",
      },
      {
        type: "story",
        foreign: "Camille sort du métro et elle est perdue. Elle voit un monsieur âgé et demande son chemin. Le monsieur lui explique qu'elle doit prendre la deuxième rue à gauche, traverser le boulevard, et le musée est juste en face. Camille le remercie et arrive au musée dix minutes plus tard.",
        english: "Camille comes out of the metro and she is lost. She sees an elderly gentleman and asks for directions. The gentleman explains that she must take the second street on the left, cross the boulevard, and the museum is right opposite. Camille thanks him and arrives at the museum ten minutes later.",
      },
      {
        type: "dialogue",
        foreign: "— Pardon, je cherche la rue de Rivoli. C'est loin ?\n— Pas du tout. Continuez tout droit jusqu'au carrefour, puis tournez à droite. C'est à environ deux cents mètres.\n— Je dois traverser la place ?\n— Non, pas la place. Restez sur le trottoir de gauche.\n— Merci beaucoup, monsieur !",
        english: "— Excuse me, I'm looking for Rue de Rivoli. Is it far?\n— Not at all. Continue straight ahead to the intersection, then turn right. It's about two hundred metres away.\n— Do I have to cross the square?\n— No, not the square. Stay on the left pavement.\n— Thank you very much, sir!",
        prompt: "This is a real-world direction exchange. Listen for the key direction words. Then repeat the question: 'Je cherche la rue de Rivoli. C'est loin ?'",
      },
      {
        type: "practice",
        foreign: "Prenez la première rue à droite. Traversez le pont. C'est en face de la gare.",
        english: "Take the first street on the right. Cross the bridge. It's opposite the train station.",
        prompt: "Say these three direction instructions aloud as if you're guiding someone.",
      },
    ],
  },
  {
    title: "At the Hotel",
    nativeTitle: "À l'hôtel",
    difficulty: 3,
    estimatedMinutes: 15,
    theme: "Booking, checking in, making requests",
    segments: [
      {
        type: "intro",
        english: "You've arrived in France and you're checking into your hotel. Today you'll learn how to book a room, state your preferences, and make requests. You'll also encounter the verb 'pouvoir' — to be able to — which is endlessly useful.",
      },
      {
        type: "phrase",
        foreign: "J'ai une réservation au nom de Martin.",
        english: "I have a reservation in the name of Martin.",
        prompt: "Replace 'Martin' with your own surname. Repeat: J'ai une réservation au nom de...",
      },
      {
        type: "phrase",
        foreign: "Est-ce que je peux avoir une chambre avec vue sur la mer ?",
        english: "Can I have a room with a sea view?",
        prompt: "'Est-ce que je peux' = 'Can I'. This structure works for dozens of requests. Repeat it.",
      },
      {
        type: "dialogue",
        foreign: "— Bonsoir, j'ai une réservation pour deux nuits au nom de Leclerc.\n— Bonsoir monsieur. Oui, une chambre double avec salle de bain, c'est bien ça ?\n— Oui, c'est exact. Est-ce que vous pouvez me montrer la chambre avant ?\n— Bien sûr. Permettez-moi de vous accompagner.",
        english: "— Good evening, I have a reservation for two nights in the name of Leclerc.\n— Good evening sir. Yes, a double room with bathroom, is that right?\n— Yes, that's correct. Can you show me the room first?\n— Of course. Allow me to accompany you.",
        prompt: "Listen to the formal tone. Hotels use 'vous' exclusively. Repeat the guest's lines.",
      },
      {
        type: "story",
        foreign: "Arnaud arrive à l'hôtel après un long voyage. La réceptionniste lui remet sa clé et lui explique les horaires du petit-déjeuner : de sept heures à dix heures dans la salle à manger au rez-de-chaussée. Il y a aussi un coffre-fort dans la chambre et le wifi est gratuit. Arnaud monte au troisième étage et pose ses bagages.",
        english: "Arnaud arrives at the hotel after a long journey. The receptionist gives him his key and explains the breakfast times: from seven to ten in the dining room on the ground floor. There is also a safe in the room and the wifi is free. Arnaud goes up to the third floor and puts down his bags.",
      },
      {
        type: "tip",
        english: "In France, the ground floor is 'le rez-de-chaussée' (RDC). The first floor above ground is 'le premier étage', which is what Americans call the second floor. Don't go to 'floor 1' expecting the ground floor — you'll end up one floor too high!",
      },
      {
        type: "practice",
        foreign: "Bonjour ! J'ai une réservation pour trois nuits au nom de Smith. Est-ce que le petit-déjeuner est inclus ?",
        english: "Hello! I have a reservation for three nights in the name of Smith. Is breakfast included?",
        prompt: "Say your hotel check-in aloud. Use your own name instead of Smith.",
      },
    ],
  },
  {
    title: "Transport",
    nativeTitle: "Les transports",
    difficulty: 4,
    estimatedMinutes: 15,
    theme: "Trains, buses, buying tickets",
    segments: [
      {
        type: "intro",
        english: "France has one of the best train networks in the world. Today you'll learn how to navigate it — buying tickets, asking for platforms, and understanding announcements. This lesson introduces more complex sentence structures.",
      },
      {
        type: "phrase",
        foreign: "Un aller simple pour Lyon, s'il vous plaît. Un aller-retour pour Marseille.",
        english: "A single ticket to Lyon, please. A return ticket to Marseille.",
        prompt: "'Aller simple' = one way. 'Aller-retour' = return. Repeat both.",
      },
      {
        type: "phrase",
        foreign: "À quelle heure part le prochain train pour Paris ?",
        english: "At what time does the next train to Paris leave?",
        prompt: "This long question is very useful at stations. Break it down: à quelle heure / part / le prochain train / pour Paris. Repeat it.",
      },
      {
        type: "dialogue",
        foreign: "— Bonjour, je voudrais un aller-retour pour Bordeaux, départ demain matin.\n— À quelle heure souhaitez-vous partir ?\n— Le plus tôt possible, avant neuf heures si possible.\n— Il y a un TGV à sept heures cinquante-deux, arrivée à dix heures seize.\n— Parfait. C'est en première ou en deuxième classe ?\n— En deuxième classe. Ça vous convient ?",
        english: "— Hello, I'd like a return ticket to Bordeaux, departing tomorrow morning.\n— What time would you like to leave?\n— As early as possible, before nine if possible.\n— There's a TGV at seven fifty-two, arriving at ten sixteen.\n— Perfect. Is that first or second class?\n— Second class. Does that suit you?",
        prompt: "Notice 'le plus tôt possible' — as early as possible. And 'Ça vous convient ?' — Does that suit you? These are useful phrases. Repeat the customer's lines.",
      },
      {
        type: "story",
        foreign: "Le TGV entre en gare à grande vitesse et s'arrête exactement à quai numéro trois. Les voyageurs montent rapidement. Julien cherche son siège : numéro quarante-deux, côté fenêtre. Il pose son sac dans le compartiment à bagages et s'installe confortablement. Dans deux heures, il sera à Paris.",
        english: "The TGV enters the station at high speed and stops exactly at platform three. The passengers board quickly. Julien looks for his seat: number forty-two, window side. He puts his bag in the luggage compartment and settles in comfortably. In two hours, he will be in Paris.",
      },
      {
        type: "tip",
        english: "In France, you MUST validate (composter) your train ticket before boarding regional trains. Look for the yellow or orange stamping machines on the platform. Failure to stamp your ticket can result in a fine, even if you have a valid ticket.",
      },
      {
        type: "practice",
        foreign: "Je voudrais un aller simple pour Nice, s'il vous plaît. Quel est le prix ? Et à quelle heure part le prochain train ?",
        english: "I would like a single to Nice, please. What is the price? And at what time does the next train leave?",
        prompt: "Say all three questions at the ticket counter, one after another.",
      },
    ],
  },
  {
    title: "Health and Body",
    nativeTitle: "Santé et corps",
    difficulty: 4,
    estimatedMinutes: 15,
    theme: "Describing symptoms, at the doctor",
    segments: [
      {
        type: "intro",
        english: "This lesson covers essential health vocabulary — body parts, describing how you feel, and visiting a doctor. Even if you never get sick in France, this vocabulary is used constantly in everyday conversation.",
      },
      {
        type: "phrase",
        foreign: "J'ai mal à la tête. J'ai mal au ventre. J'ai mal à la gorge.",
        english: "I have a headache. I have a stomachache. I have a sore throat.",
        prompt: "'J'ai mal à' + body part = 'I have pain in my'. Repeat all three with the correct body parts.",
      },
      {
        type: "phrase",
        foreign: "Je me sens mal. Je suis fatigué(e). J'ai de la fièvre.",
        english: "I feel unwell. I am tired. I have a fever.",
        prompt: "These general health phrases are crucial. Repeat each one.",
      },
      {
        type: "dialogue",
        foreign: "— Bonjour, je n'ai pas très bonne mine. Qu'est-ce qui ne va pas ?\n— J'ai mal à la gorge depuis trois jours et j'ai un peu de fièvre.\n— Est-ce que vous toussez ?\n— Oui, surtout la nuit. Et j'ai mal à la tête aussi.\n— Ouvrez la bouche, s'il vous plaît. ... Vous avez une angine. Je vais vous prescrire des antibiotiques.",
        english: "— Hello, you don't look very well. What's wrong?\n— I've had a sore throat for three days and a slight fever.\n— Are you coughing?\n— Yes, especially at night. And I have a headache too.\n— Open your mouth, please. ... You have tonsillitis. I'm going to prescribe you antibiotics.",
        prompt: "Listen to the doctor-patient exchange. Notice 'depuis' — 'for' (duration). 'J'ai mal à la gorge depuis trois jours' = 'I've had a sore throat for three days'. Repeat the patient's lines.",
      },
      {
        type: "story",
        foreign: "Lucie se réveille un matin avec un mal de tête terrible. Elle a chaud et froid en même temps. Sa mère lui prend la température : trente-neuf degrés. Lucie appelle son médecin pour prendre rendez-vous. Le médecin peut la recevoir à onze heures. Lucie prend de l'aspirine en attendant.",
        english: "Lucie wakes up one morning with a terrible headache. She feels hot and cold at the same time. Her mother takes her temperature: thirty-nine degrees. Lucie calls her doctor to make an appointment. The doctor can see her at eleven. Lucie takes aspirin in the meantime.",
      },
      {
        type: "tip",
        english: "In France, visiting a doctor costs around 25–30 euros for a standard consultation (médecin généraliste). With a French health card (Carte Vitale), most of that is reimbursed. Emergency care goes to 'les urgences' at the nearest hospital. Call 15 (SAMU) for medical emergencies.",
      },
      {
        type: "practice",
        foreign: "Bonjour docteur. Je me sens très mal depuis hier. J'ai de la fièvre, mal à la tête, et je tousse beaucoup.",
        english: "Hello doctor. I've been feeling very unwell since yesterday. I have a fever, a headache, and I'm coughing a lot.",
        prompt: "Say your symptoms to the doctor. Use this as a template and adapt it if needed.",
      },
    ],
  },
  {
    title: "At the Restaurant",
    nativeTitle: "Au restaurant",
    difficulty: 4,
    estimatedMinutes: 15,
    theme: "Full dining experience, expressing opinions",
    segments: [
      {
        type: "intro",
        english: "This lesson is a full restaurant experience from arrival to dessert. You'll learn formal ordering language, how to ask about the menu, how to express what you think of the food, and how to handle the bill like a local.",
      },
      {
        type: "phrase",
        foreign: "Avez-vous une table pour deux personnes, s'il vous plaît ?",
        english: "Do you have a table for two, please?",
        prompt: "Your opening line at the restaurant. Repeat clearly.",
      },
      {
        type: "phrase",
        foreign: "Qu'est-ce que vous nous recommandez ? Quel est le plat du jour ?",
        english: "What do you recommend? What is the dish of the day?",
        prompt: "These two questions will make you sound like a confident diner. Repeat them.",
      },
      {
        type: "dialogue",
        foreign: "— Bonsoir ! Vous avez réservé ?\n— Oui, au nom de Fontaine, pour deux personnes.\n— Très bien. Par ici, s'il vous plaît. Voici la carte.\n— Merci. Qu'est-ce que vous recommandez comme plat principal ?\n— Ce soir, je vous conseille le magret de canard, c'est la spécialité de la maison.\n— Parfait, je vais prendre ça. Et ma femme prendra la sole meunière.",
        english: "— Good evening! Have you booked?\n— Yes, in the name of Fontaine, for two.\n— Very good. This way please. Here is the menu.\n— Thank you. What do you recommend as a main course?\n— This evening, I recommend the duck breast, it's the house speciality.\n— Perfect, I'll have that. And my wife will have the sole meunière.",
        prompt: "Listen to the level of formality. Then repeat the guest's lines — notice 'je vais prendre' (I'll have / I'm going to take).",
      },
      {
        type: "phrase",
        foreign: "C'est délicieux ! Le plat est un peu trop salé. Je voudrais un autre verre de vin.",
        english: "It's delicious! The dish is a bit too salty. I would like another glass of wine.",
        prompt: "Expressing opinions about food. Repeat each sentence — notice 'un peu trop' = a little too much.",
      },
      {
        type: "story",
        foreign: "Le repas se passe à merveille. En entrée, ils ont choisi une soupe à l'oignon. Pour le plat principal, Pierre a pris le bœuf bourguignon et Hélène a choisi le saumon. Le dessert — une tarte Tatin — était absolument succulent. Le serveur leur apporte l'addition et ils laissent un pourboire généreux.",
        english: "The meal goes wonderfully. For the starter, they chose onion soup. For the main course, Pierre had the bœuf bourguignon and Hélène chose the salmon. The dessert — a tarte Tatin — was absolutely delicious. The waiter brings them the bill and they leave a generous tip.",
      },
      {
        type: "tip",
        english: "A French dinner has a clear structure: l'entrée (starter), le plat principal (main course), le fromage (cheese), and le dessert. Eating cheese before dessert is typically French, not after. Skipping courses is perfectly acceptable — just let the waiter know.",
      },
      {
        type: "practice",
        foreign: "Excusez-moi, le plat est excellent, mais je n'ai pas commandé ça. J'ai commandé le poulet rôti, pas le bœuf.",
        english: "Excuse me, the dish is excellent, but I didn't order that. I ordered the roast chicken, not the beef.",
        prompt: "A polite correction — very useful! Say it aloud with confidence but courtesy.",
      },
    ],
  },
  {
    title: "A Day in Paris",
    nativeTitle: "Une journée à Paris",
    difficulty: 5,
    estimatedMinutes: 16,
    theme: "Complex narration, past tense, advanced expressions",
    segments: [
      {
        type: "intro",
        english: "You've reached lesson fourteen — the most advanced story so far. Today you'll encounter the passé composé, the main past tense used in French conversation. You'll also see more complex sentence structures and richer vocabulary. This is the kind of French you'll hear from native speakers.",
      },
      {
        type: "phrase",
        foreign: "Je suis allé(e) au musée. J'ai visité la tour Eiffel. Nous avons pris le métro.",
        english: "I went to the museum. I visited the Eiffel Tower. We took the metro.",
        prompt: "The passé composé = 'avoir' or 'être' + past participle. Listen for 'ai' and 'suis'. Repeat all three.",
      },
      {
        type: "story",
        foreign: "Hier, Clara et son amie Nadia ont passé une journée extraordinaire à Paris. Elles se sont levées tôt pour éviter la foule au Louvre. Après deux heures de musée, elles ont déjeuné dans un bistrot du quartier Latin. L'après-midi, elles ont flâné le long de la Seine et ont acheté des cartes postales. Le soir, elles ont grimpé la butte Montmartre et ont regardé le coucher du soleil depuis le Sacré-Cœur. Clara a dit : « Cette journée est parfaite. » Nadia a souri et répondu : « Paris ne déçoit jamais. »",
        english: "Yesterday, Clara and her friend Nadia spent an extraordinary day in Paris. They got up early to avoid the crowds at the Louvre. After two hours in the museum, they had lunch in a bistro in the Latin Quarter. In the afternoon, they strolled along the Seine and bought postcards. In the evening, they climbed Montmartre hill and watched the sunset from Sacré-Cœur. Clara said: 'This day is perfect.' Nadia smiled and replied: 'Paris never disappoints.'",
      },
      {
        type: "dialogue",
        foreign: "— Alors, cette journée à Paris, c'était comment ?\n— Incroyable ! On a fait tellement de choses. Le matin on était au Louvre, et le soir on regardait le coucher du soleil depuis Montmartre.\n— Tu as mangé quelque chose de bon ?\n— Oui ! On a trouvé un petit restaurant dans une ruelle. Le patron était adorable. J'ai pris un bœuf bourguignon — c'était à tomber par terre.\n— Je suis jaloux ! Tu y retournes quand ?\n— Dès que possible !",
        english: "— So, how was that day in Paris?\n— Incredible! We did so many things. In the morning we were at the Louvre, and in the evening we were watching the sunset from Montmartre.\n— Did you eat something good?\n— Yes! We found a little restaurant in a side street. The owner was adorable. I had bœuf bourguignon — it was out of this world.\n— I'm jealous! When are you going back?\n— As soon as possible!",
        prompt: "'C'était à tomber par terre' — literally 'it was enough to fall to the floor' — means it was incredibly good. Listen for these idiomatic expressions. Repeat Clara's first response.",
      },
      {
        type: "tip",
        english: "The passé composé is the most important past tense for conversation. It uses 'avoir' (to have) or 'être' (to be) as a helper verb. Most verbs use 'avoir': j'ai mangé (I ate). But verbs of movement and reflexive verbs use 'être': je suis allé (I went), je me suis levé (I got up). This distinction takes time — be patient with yourself.",
      },
      {
        type: "practice",
        foreign: "Hier, j'ai visité un musée, j'ai déjeuné dans un café et je suis rentré(e) à l'hôtel à dix-neuf heures.",
        english: "Yesterday, I visited a museum, I had lunch in a café, and I returned to the hotel at seven in the evening.",
        prompt: "Say this sentence about your own imaginary day in Paris. You can substitute the activities with anything you like.",
      },
      {
        type: "phrase",
        foreign: "Ça valait vraiment le coup. Je suis épuisé(e) mais tellement heureux/heureuse.",
        english: "It was really worth it. I'm exhausted but so happy.",
        prompt: "'Ça vaut le coup' = it's worth it. One of the most useful French expressions. Repeat both sentences.",
      },
    ],
  },
];

// ─────────────────────────────────────────────────────────────────────────────
// SPANISH STORIES  (14 lessons, cycling daily, easiest → hardest)
// ─────────────────────────────────────────────────────────────────────────────
export const spanishStories: Story[] = [
  {
    title: "First Greetings",
    nativeTitle: "Los primeros saludos",
    difficulty: 1,
    estimatedMinutes: 12,
    theme: "Greetings & essential politeness",
    segments: [
      {
        type: "intro",
        english: "Welcome to your first Spanish lesson. Today you will learn the most essential greetings and polite expressions in Spanish. Repeat every phrase aloud — that repetition is the key to making it stick. Let's begin.",
      },
      {
        type: "phrase",
        foreign: "¡Hola!",
        english: "Hello!",
        prompt: "The most universal Spanish greeting. Casual and warm. Say it: ¡Hola!",
      },
      {
        type: "phrase",
        foreign: "Buenos días. Buenas tardes. Buenas noches.",
        english: "Good morning. Good afternoon. Good night.",
        prompt: "Three essential time-of-day greetings. Repeat each one clearly.",
      },
      {
        type: "phrase",
        foreign: "¿Cómo estás? — Muy bien, gracias. ¿Y tú?",
        english: "How are you? — Very well, thank you. And you?",
        prompt: "The classic greeting exchange. Repeat the question, then the answer.",
      },
      {
        type: "phrase",
        foreign: "Por favor. Gracias. De nada.",
        english: "Please. Thank you. You're welcome.",
        prompt: "The three pillars of politeness. Repeat: por favor, gracias, de nada.",
      },
      {
        type: "story",
        foreign: "Carlos entra en una tienda por la mañana. Ve al dependiente y dice: '¡Buenos días!' El dependiente sonríe y responde: '¡Buenos días! ¿En qué le puedo ayudar?' Carlos responde: 'Gracias, solo estoy mirando.'",
        english: "Carlos enters a shop in the morning. He sees the shop assistant and says: 'Good morning!' The assistant smiles and replies: 'Good morning! How can I help you?' Carlos replies: 'Thank you, I'm just browsing.'",
      },
      {
        type: "dialogue",
        foreign: "— ¡Hola! ¿Cómo estás?\n— ¡Muy bien, gracias! ¿Y tú?\n— Bien también, gracias. ¡Hasta luego!\n— ¡Hasta luego! ¡Que tengas un buen día!",
        english: "— Hello! How are you?\n— Very well, thank you! And you?\n— Well too, thank you. Goodbye!\n— Goodbye! Have a good day!",
        prompt: "Notice '¡Hasta luego!' — see you later. And '¡Que tengas un buen día!' — have a good day. Repeat the exchange.",
      },
      {
        type: "practice",
        foreign: "¡Buenos días! ¿Cómo estás? — Muy bien, gracias. ¿Y tú?",
        english: "Good morning! How are you? — Very well, thank you. And you?",
        prompt: "Play both sides of this exchange aloud. Speak with warmth.",
      },
      {
        type: "tip",
        english: "Spanish has two words for 'you' — 'tú' (informal, used with friends and family) and 'usted' (formal, used with strangers, elders, and in professional settings). In Latin America, 'usted' is used more widely than in Spain. When in doubt, use 'usted' — it's always polite.",
      },
    ],
  },
  {
    title: "At the Bakery",
    nativeTitle: "En la panadería",
    difficulty: 1,
    estimatedMinutes: 13,
    theme: "Shopping, numbers, and ordering",
    segments: [
      {
        type: "intro",
        english: "Today you're at a Caribbean bakery — a panadería. You'll learn how to order, ask for prices, and use numbers one to ten. In the Dominican Republic and many Latin American countries, the bakery is the heart of the neighborhood.",
      },
      {
        type: "phrase",
        foreign: "Quisiera un pan de agua, por favor.",
        english: "I would like a water bread, please.",
        prompt: "'Quisiera' is a polite way to say 'I would like'. Repeat: Quisiera...",
      },
      {
        type: "phrase",
        foreign: "¿Cuánto cuesta? ¿Cuánto es?",
        english: "How much does it cost? How much is it?",
        prompt: "Two ways to ask the price. Both are common. Repeat both.",
      },
      {
        type: "phrase",
        foreign: "Uno, dos, tres, cuatro, cinco, seis, siete, ocho, nueve, diez.",
        english: "One, two, three, four, five, six, seven, eight, nine, ten.",
        prompt: "The first ten numbers in Spanish. Repeat them all slowly and clearly.",
      },
      {
        type: "story",
        foreign: "Ana entra en la panadería de su barrio cada mañana. Saluda a doña Carmen, la panadera, y pide tres panecillos y un café. Doña Carmen le cobra cincuenta pesos. Ana le da cien pesos y recibe el cambio. Se despiden con una sonrisa.",
        english: "Ana enters her neighborhood bakery every morning. She greets doña Carmen, the baker, and asks for three rolls and a coffee. Doña Carmen charges her fifty pesos. Ana gives her a hundred pesos and receives her change. They say goodbye with a smile.",
      },
      {
        type: "dialogue",
        foreign: "— ¡Buenos días, doña Carmen!\n— ¡Buenos días! ¿Qué va a llevar hoy?\n— Quisiera dos panes y una botella de agua, por favor.\n— Claro. Son treinta pesos.\n— Aquí tiene. ¡Muchas gracias!\n— ¡A usted! ¡Que pase bien!",
        english: "— Good morning, doña Carmen!\n— Good morning! What will you be taking today?\n— I would like two breads and a bottle of water, please.\n— Of course. That's thirty pesos.\n— Here you are. Thank you very much!\n— You're welcome! Have a great day!",
        prompt: "'¿Qué va a llevar?' literally means 'What are you going to take?' — it's how vendors ask what you want. Repeat the customer's lines.",
      },
      {
        type: "tip",
        english: "In the Dominican Republic, 'pan de agua' (water bread) is a staple — a soft, light roll eaten at breakfast with butter, cheese, or salami. It's different from crusty European bread. Food terms vary widely across Spanish-speaking countries, so always context is key.",
      },
      {
        type: "practice",
        foreign: "Quisiera cinco panecillos y dos botellas de agua, por favor. ¿Cuánto es?",
        english: "I would like five rolls and two bottles of water, please. How much is it?",
        prompt: "Say your order at the counter and ask for the price.",
      },
    ],
  },
  {
    title: "Introducing Yourself",
    nativeTitle: "Presentarse",
    difficulty: 2,
    estimatedMinutes: 14,
    theme: "Names, origin, and basic description",
    segments: [
      {
        type: "intro",
        english: "Today you'll learn how to introduce yourself in Spanish — your name, where you're from, your age, and what you do. These sentences form the foundation of every new conversation you'll ever have.",
      },
      {
        type: "phrase",
        foreign: "Me llamo Diego.",
        english: "My name is Diego.",
        prompt: "Replace Diego with your own name. 'Me llamo' literally means 'I call myself'. Repeat: Me llamo...",
      },
      {
        type: "phrase",
        foreign: "Tengo veinticinco años.",
        english: "I am twenty-five years old.",
        prompt: "In Spanish, 'I have years' not 'I am years old'. Try with your own age: Tengo... años.",
      },
      {
        type: "phrase",
        foreign: "Soy estadounidense. Soy dominicano/dominicana.",
        english: "I am American. I am Dominican. (male/female)",
        prompt: "Nationalities often change ending depending on gender. -o for male, -a for female. Repeat both.",
      },
      {
        type: "story",
        foreign: "Laura es una estudiante estadounidense que estudia español en Santo Domingo. Tiene veintidós años y viene de Chicago. Hoy conoce a su vecino, Miguel. Miguel tiene treinta años, es dominicano y trabaja en un hospital. Los dos se presentan y descubren que los dos hablan un poco de inglés y español.",
        english: "Laura is an American student studying Spanish in Santo Domingo. She is twenty-two and comes from Chicago. Today she meets her neighbor Miguel. Miguel is thirty, is Dominican, and works in a hospital. The two introduce themselves and discover that both speak a little English and Spanish.",
      },
      {
        type: "dialogue",
        foreign: "— ¡Hola! Me llamo Laura. ¿Y tú?\n— ¡Mucho gusto! Yo soy Miguel. ¿De dónde eres?\n— Soy de Chicago, Estados Unidos. ¿Y tú?\n— Soy dominicano, de Santiago. ¿Cuánto tiempo llevas en el país?\n— Solo tres semanas, pero me encanta.",
        english: "— Hello! My name is Laura. And you?\n— Nice to meet you! I'm Miguel. Where are you from?\n— I'm from Chicago, United States. And you?\n— I'm Dominican, from Santiago. How long have you been in the country?\n— Only three weeks, but I love it.",
        prompt: "'Mucho gusto' = nice to meet you. '¿De dónde eres?' = where are you from? Repeat Laura's lines in the dialogue.",
      },
      {
        type: "practice",
        foreign: "Me llamo... Tengo... años. Soy de... Mucho gusto.",
        english: "My name is... I am... years old. I am from... Nice to meet you.",
        prompt: "Fill in your own details and say your full introduction aloud.",
      },
    ],
  },
  {
    title: "Numbers and Time",
    nativeTitle: "Los números y la hora",
    difficulty: 2,
    estimatedMinutes: 14,
    theme: "Telling the time, days of the week",
    segments: [
      {
        type: "intro",
        english: "Time expressions are used in every single conversation. Today you'll master telling the time in Spanish, learn the days of the week, and use common time expressions. After this lesson, making and understanding appointments will feel natural.",
      },
      {
        type: "phrase",
        foreign: "¿Qué hora es? — Son las tres. Es la una.",
        english: "What time is it? — It is three o'clock. It is one o'clock.",
        prompt: "Note: 'es la una' (it is one), but 'son las...' for all other hours (they are...). Repeat both answers.",
      },
      {
        type: "phrase",
        foreign: "Lunes, martes, miércoles, jueves, viernes, sábado, domingo.",
        english: "Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday.",
        prompt: "Days are not capitalised in Spanish. Repeat them all at a steady pace.",
      },
      {
        type: "phrase",
        foreign: "Son las ocho y cuarto. Son las nueve y media. Son las diez menos cuarto.",
        english: "It is quarter past eight. It is half past nine. It is quarter to ten.",
        prompt: "'Y cuarto' = quarter past. 'Y media' = half past. 'Menos cuarto' = quarter to. Repeat all three.",
      },
      {
        type: "story",
        foreign: "El lunes por la mañana, Carmen se despierta a las seis y media. Desayuna a las siete. Sale de casa a las ocho menos cuarto. Tiene una reunión importante el miércoles a las diez de la mañana. El viernes por la noche tiene planes con sus amigos.",
        english: "On Monday morning, Carmen wakes up at half past six. She has breakfast at seven. She leaves the house at quarter to eight. She has an important meeting on Wednesday at ten in the morning. On Friday evening she has plans with her friends.",
      },
      {
        type: "dialogue",
        foreign: "— Perdona, ¿qué hora es?\n— Son las dos y veinte.\n— ¿En serio? ¡Mi cita era a las dos!\n— No te preocupes, está a dos minutos de aquí.\n— Muchas gracias. ¡Hasta luego!",
        english: "— Excuse me, what time is it?\n— It's twenty past two.\n— Really? My appointment was at two!\n— Don't worry, it's two minutes from here.\n— Thank you very much. Goodbye!",
        prompt: "Notice 'No te preocupes' — don't worry. Very useful! Repeat the first person's lines.",
      },
      {
        type: "practice",
        foreign: "Son las once y media. Mi reunión es el jueves a las nueve de la mañana.",
        english: "It is half past eleven. My meeting is on Thursday at nine in the morning.",
        prompt: "Say both time expressions clearly. Then make up your own schedule sentence.",
      },
    ],
  },
  {
    title: "The Family",
    nativeTitle: "La familia",
    difficulty: 2,
    estimatedMinutes: 13,
    theme: "Family members and possessives",
    segments: [
      {
        type: "intro",
        english: "Family — la familia — is at the heart of Latin American culture. Today you'll learn the words for family members and how to describe your own family using possessive words like 'my', 'your', and 'his'.",
      },
      {
        type: "phrase",
        foreign: "Mi padre, mi madre, mi hermano, mi hermana.",
        english: "My father, my mother, my brother, my sister.",
        prompt: "'Mi' means 'my' in Spanish and doesn't change for gender. Repeat: mi padre, mi madre, mi hermano, mi hermana.",
      },
      {
        type: "phrase",
        foreign: "Mi abuelo, mi abuela, mi tío, mi tía, mi primo, mi prima.",
        english: "My grandfather, my grandmother, my uncle, my aunt, my male cousin, my female cousin.",
        prompt: "Repeat each extended family member clearly.",
      },
      {
        type: "story",
        foreign: "La familia Rodríguez es muy unida. El padre se llama Roberto y la madre se llama Patricia. Tienen cuatro hijos: dos chicos y dos chicas. Los domingos, toda la familia se reúne en casa de los abuelos para almorzar juntos. Los abuelos viven en el campo, lejos de la ciudad, pero esa reunión semanal es sagrada para todos.",
        english: "The Rodríguez family is very close. The father's name is Roberto and the mother's name is Patricia. They have four children: two boys and two girls. On Sundays, the whole family gathers at the grandparents' house to have lunch together. The grandparents live in the countryside, far from the city, but that weekly gathering is sacred for everyone.",
      },
      {
        type: "dialogue",
        foreign: "— ¿Tienes hermanos?\n— Sí, tengo dos hermanos y una hermana. Y tú, ¿tienes familia aquí?\n— Sí, mis padres viven aquí, y mi abuela también. Ella tiene ochenta años y está muy bien.\n— ¡Qué bien! Mi familia está en el campo.",
        english: "— Do you have siblings?\n— Yes, I have two brothers and a sister. And you, do you have family here?\n— Yes, my parents live here, and my grandmother too. She is eighty and is doing very well.\n— How lovely! My family is in the countryside.",
        prompt: "Listen to the natural conversational flow. '¿Tienes hermanos?' = do you have siblings? Repeat the first person's answers.",
      },
      {
        type: "practice",
        foreign: "En mi familia somos... personas. Tengo... Mi madre se llama... y mi padre se llama...",
        english: "In my family there are... people. I have... My mother's name is... and my father's name is...",
        prompt: "Fill in your own family details and speak your description aloud.",
      },
    ],
  },
  {
    title: "At the Café",
    nativeTitle: "En el café",
    difficulty: 2,
    estimatedMinutes: 14,
    theme: "Ordering drinks, expressing likes",
    segments: [
      {
        type: "intro",
        english: "The café is the social heartbeat of Latin America. Today you'll learn how to order drinks, express what you like, and ask for the bill. You'll also learn the difference between 'me gusta' and 'quiero'.",
      },
      {
        type: "phrase",
        foreign: "Quisiera un café con leche, por favor.",
        english: "I would like a coffee with milk, please.",
        prompt: "Polite ordering. Repeat: Quisiera un café con leche.",
      },
      {
        type: "phrase",
        foreign: "Me gusta el café. No me gusta el té.",
        english: "I like coffee. I don't like tea.",
        prompt: "'Me gusta' = it pleases me = I like it. Repeat both. Now try with something you like.",
      },
      {
        type: "dialogue",
        foreign: "— ¡Buenas! ¿Qué le traigo?\n— Quisiera un zumo de naranja y un agua con gas, por favor.\n— ¿Algo más?\n— Sí, también quisiera una tostada con mantequilla.\n— Enseguida. ¿Va a pagar con tarjeta o en efectivo?\n— En efectivo.",
        english: "— Hello! What can I bring you?\n— I would like an orange juice and a sparkling water, please.\n— Anything else?\n— Yes, I would also like a slice of toast with butter.\n— Right away. Will you pay by card or cash?\n— In cash.",
        prompt: "Notice '¿Algo más?' — anything else? And 'enseguida' — right away. Repeat the customer's lines.",
      },
      {
        type: "phrase",
        foreign: "La cuenta, por favor.",
        english: "The bill, please.",
        prompt: "Essential. Say it clearly: La cuenta, por favor.",
      },
      {
        type: "tip",
        english: "In the Dominican Republic and much of Latin America, coffee culture is strong. 'Café dominicano' is typically sweet, strong, and served in a small cup. Ordering 'un café' without specifying usually gets you this style. If you want a longer drink, ask for 'un café americano'.",
      },
      {
        type: "practice",
        foreign: "Quisiera un café, un zumo de mango y dos tostadas, por favor. ¿Cuánto es? La cuenta, por favor.",
        english: "I would like a coffee, a mango juice, and two toasts, please. How much is it? The bill, please.",
        prompt: "Run through your full café order and ask for the bill.",
      },
    ],
  },
  {
    title: "Around Town",
    nativeTitle: "En la ciudad",
    difficulty: 3,
    estimatedMinutes: 15,
    theme: "Places in the city, asking for locations",
    segments: [
      {
        type: "intro",
        english: "You're exploring a new city. Today you'll learn the names of essential places and how to ask where things are. You'll use 'hay' — there is / there are — and key prepositions like 'cerca de' and 'al lado de'.",
      },
      {
        type: "phrase",
        foreign: "¿Dónde está el banco, por favor?",
        english: "Where is the bank, please?",
        prompt: "The most essential direction question. Repeat: ¿Dónde está...?",
      },
      {
        type: "phrase",
        foreign: "El banco, la farmacia, el supermercado, el hospital, la comisaría.",
        english: "The bank, the pharmacy, the supermarket, the hospital, the police station.",
        prompt: "Learn these city places. Repeat each one.",
      },
      {
        type: "phrase",
        foreign: "Está a la izquierda. Está a la derecha. Siga recto. Está cerca de aquí.",
        english: "It's on the left. It's on the right. Go straight. It's nearby.",
        prompt: "Essential direction responses. Repeat each one.",
      },
      {
        type: "story",
        foreign: "Pedro llega a una ciudad nueva y necesita encontrar una farmacia. Para él es urgente porque su hijo tiene fiebre. Pregunta a una señora en la calle: '¿Sabe dónde hay una farmacia por aquí?' La señora le explica que hay una a tres cuadras, detrás del parque central.",
        english: "Pedro arrives in a new city and needs to find a pharmacy. It's urgent for him because his son has a fever. He asks a lady on the street: 'Do you know if there's a pharmacy around here?' The lady explains that there is one three blocks away, behind the main park.",
      },
      {
        type: "dialogue",
        foreign: "— Perdone, ¿hay un cajero automático por aquí?\n— Sí, hay uno a la vuelta de la esquina, al lado del supermercado.\n— ¿Está muy lejos?\n— No, está a dos minutos caminando. Siga recto y gire a la derecha.\n— Muchas gracias. ¡Muy amable!",
        english: "— Excuse me, is there an ATM around here?\n— Yes, there's one around the corner, next to the supermarket.\n— Is it very far?\n— No, it's two minutes walking. Go straight and turn right.\n— Thank you very much. How kind!",
        prompt: "Listen for 'a la vuelta de la esquina' — around the corner. And '¡Muy amable!' — how kind / very kind. Repeat the questioner's lines.",
      },
      {
        type: "practice",
        foreign: "Perdone, ¿sabe dónde está la estación de metro más cercana? ¿Está lejos?",
        english: "Excuse me, do you know where the nearest metro station is? Is it far?",
        prompt: "Ask these two questions as naturally as possible, as if you're genuinely lost.",
      },
    ],
  },
  {
    title: "At the Market",
    nativeTitle: "En el mercado",
    difficulty: 3,
    estimatedMinutes: 15,
    theme: "Food, quantities, and bargaining",
    segments: [
      {
        type: "intro",
        english: "The market is the lifeblood of Caribbean and Latin American commerce. Today you'll learn food and quantity vocabulary and how to handle a real market interaction — including a bit of friendly bargaining.",
      },
      {
        type: "phrase",
        foreign: "Un kilo de tomates. Medio kilo de mangos. Una libra de arroz.",
        english: "A kilo of tomatoes. Half a kilo of mangoes. A pound of rice.",
        prompt: "Note: in the Dominican Republic 'una libra' is 453 grams — used alongside kilos. Repeat each quantity.",
      },
      {
        type: "phrase",
        foreign: "¿Está fresco? ¿Cuánto vale el kilo? ¿Tiene algo más barato?",
        english: "Is it fresh? How much is a kilo? Do you have anything cheaper?",
        prompt: "These are your market weapons. Repeat all three.",
      },
      {
        type: "story",
        foreign: "El Mercado Modelo de Santo Domingo es uno de los mercados más animados del Caribe. Doña Rosa tiene un puesto de frutas tropicales: mangos, guanábanas, papayas y plátanos. Cada mañana llegan clientes de todo el vecindario. Doña Rosa conoce a todos por su nombre y siempre ofrece una fruta de muestra a los que miran.",
        english: "The Mercado Modelo in Santo Domingo is one of the most lively markets in the Caribbean. Doña Rosa has a stall with tropical fruits: mangoes, soursop, papayas, and plantains. Every morning, customers come from all over the neighborhood. Doña Rosa knows everyone by name and always offers a taste of fruit to those who browse.",
      },
      {
        type: "dialogue",
        foreign: "— ¡Buenas! ¿Cuánto están los mangos hoy?\n— A veinte pesos la libra, señora.\n— Ay, eso está caro. ¿No me los da a quince?\n— No puedo, señora, pero le doy una libra y media por veinticinco.\n— Bueno, trato. ¡Dame dos libras y media!\n— ¡Con mucho gusto!",
        english: "— Hello! How much are the mangoes today?\n— Twenty pesos a pound, ma'am.\n— That's expensive. Won't you give them to me for fifteen?\n— I can't, ma'am, but I'll give you a pound and a half for twenty-five.\n— Alright, deal! Give me two and a half pounds!\n— With pleasure!",
        prompt: "This is real market bartering. Notice 'trato' — deal! And '¡Con mucho gusto!' — with pleasure! Repeat the customer's lines.",
      },
      {
        type: "practice",
        foreign: "Quisiera dos kilos de tomates y un kilo de cebollas. ¿Está todo fresco? ¿Cuánto es en total?",
        english: "I would like two kilos of tomatoes and a kilo of onions. Is everything fresh? How much is it in total?",
        prompt: "Say your shopping list and questions as if you're at the market stall.",
      },
    ],
  },
  {
    title: "Asking for Directions",
    nativeTitle: "Cómo pedir indicaciones",
    difficulty: 3,
    estimatedMinutes: 15,
    theme: "Giving and following directions",
    segments: [
      {
        type: "intro",
        english: "You're in an unfamiliar neighborhood and need to find your way. Today's lesson focuses entirely on asking for and giving directions in Spanish. You'll learn the imperative (command) forms and more complex location phrases.",
      },
      {
        type: "phrase",
        foreign: "Gire a la izquierda. Gire a la derecha. Siga recto. Cruce el puente.",
        english: "Turn left. Turn right. Go straight ahead. Cross the bridge.",
        prompt: "These are command forms — imperative. Repeat each direction clearly.",
      },
      {
        type: "phrase",
        foreign: "Al final de la calle. En la esquina. Frente al parque. Detrás de la iglesia.",
        english: "At the end of the street. On the corner. In front of the park. Behind the church.",
        prompt: "Position phrases. Repeat each one and visualise the location.",
      },
      {
        type: "story",
        foreign: "Sofía sale del metro y está completamente perdida. Busca el Museo Nacional de Historia Natural. Pregunta a un policía que está en la esquina. El policía le explica que tiene que cruzar la avenida, girar a la derecha en el segundo semáforo, y el museo está justo frente al parque. Sofía llega en diez minutos.",
        english: "Sofía comes out of the metro and is completely lost. She's looking for the National Museum of Natural History. She asks a police officer on the corner. The officer explains that she needs to cross the avenue, turn right at the second traffic light, and the museum is right in front of the park. Sofía arrives in ten minutes.",
      },
      {
        type: "dialogue",
        foreign: "— Disculpe, ¿me podría decir cómo llegar a la Plaza de la Cultura?\n— Claro que sí. Siga por esta calle hasta el final. Al llegar al semáforo, gire a la izquierda. La Plaza de la Cultura está a unos doscientos metros, a mano derecha.\n— ¿Hay algún autobús que pase por allí?\n— Sí, el número quince para justo enfrente.\n— Perfecto. Muchísimas gracias.",
        english: "— Excuse me, could you tell me how to get to Plaza de la Cultura?\n— Of course. Continue along this street to the end. When you reach the traffic light, turn left. Plaza de la Cultura is about two hundred metres away, on the right-hand side.\n— Is there a bus that goes there?\n— Yes, the number fifteen stops right in front.\n— Perfect. Thank you very much.",
        prompt: "'¿Me podría decir...?' — could you tell me? Very polite. Repeat the question: '¿Me podría decir cómo llegar a...?'",
      },
      {
        type: "practice",
        foreign: "Disculpe, ¿cómo se llega al aeropuerto desde aquí? — Siga recto, luego gire a la derecha en el tercer semáforo.",
        english: "Excuse me, how do you get to the airport from here? — Go straight, then turn right at the third traffic light.",
        prompt: "Say both sides of this exchange aloud.",
      },
    ],
  },
  {
    title: "At the Hotel",
    nativeTitle: "En el hotel",
    difficulty: 3,
    estimatedMinutes: 15,
    theme: "Check-in, making requests, handling problems",
    segments: [
      {
        type: "intro",
        english: "You're checking into a hotel in Santo Domingo. Today you'll learn formal hotel language, how to make requests, and how to handle problems. You'll encounter 'poder' — can/to be able to — which is essential for making polite requests.",
      },
      {
        type: "phrase",
        foreign: "Tengo una reserva a nombre de Johnson.",
        english: "I have a reservation in the name of Johnson.",
        prompt: "Replace Johnson with your name. Repeat: Tengo una reserva a nombre de...",
      },
      {
        type: "phrase",
        foreign: "¿Me podría dar una habitación con vista al mar?\n¿Está incluido el desayuno?",
        english: "Could you give me a room with a sea view?\nIs breakfast included?",
        prompt: "'¿Me podría dar...?' = could you give me? A polite and powerful structure. Repeat both questions.",
      },
      {
        type: "dialogue",
        foreign: "— Buenas tardes. Tengo una reserva a nombre de García, por dos noches.\n— Buenas tardes, señor García. Un momento... sí, aquí está. Habitación doble, piso cuatro.\n— ¿Es posible tener una habitación más alta? Prefiero las vistas.\n— Por supuesto. Le asigno la habitación 612, con vista a la piscina y el mar.\n— Perfecto. ¿A qué hora es el desayuno?\n— De siete a diez en el restaurante de la planta baja.",
        english: "— Good afternoon. I have a reservation in the name of García, for two nights.\n— Good afternoon, Mr García. One moment... yes, here it is. Double room, fourth floor.\n— Is it possible to have a higher room? I prefer the views.\n— Of course. I'll assign you room 612, with a view of the pool and the sea.\n— Perfect. What time is breakfast?\n— From seven to ten in the restaurant on the ground floor.",
        prompt: "Notice 'planta baja' — ground floor (same as French rez-de-chaussée). Repeat the guest's lines.",
      },
      {
        type: "story",
        foreign: "El hotel Catalonia de Santo Domingo está situado frente al malecón. Después de hacer el check-in, los turistas suben a su habitación. La vista al mar Caribe es espectacular. El aire acondicionado funciona perfectamente y la cama es enorme. Solo hay un pequeño problema: el wifi no funciona. Bajan a recepción para quejarse.",
        english: "The Hotel Catalonia in Santo Domingo is situated in front of the Malecón. After checking in, the tourists go up to their room. The view of the Caribbean Sea is spectacular. The air conditioning works perfectly and the bed is enormous. There is only one small problem: the wifi doesn't work. They go down to reception to complain.",
      },
      {
        type: "practice",
        foreign: "Perdone, hay un problema con el wifi en mi habitación. ¿Me puede ayudar?",
        english: "Excuse me, there's a problem with the wifi in my room. Can you help me?",
        prompt: "Say this politely, as you would to the receptionist.",
      },
    ],
  },
  {
    title: "Transport",
    nativeTitle: "El transporte",
    difficulty: 4,
    estimatedMinutes: 15,
    theme: "Buses, taxis, buying tickets",
    segments: [
      {
        type: "intro",
        english: "Getting around is essential. Today you'll learn how to take a bus, hail a taxi, buy tickets, and handle the transport conversations you'll actually have. This lesson also introduces more complex verb structures.",
      },
      {
        type: "phrase",
        foreign: "¿A qué hora sale el próximo autobús para Santiago?\nQuisiera un boleto de ida y vuelta.",
        english: "At what time does the next bus to Santiago leave?\nI would like a return ticket.",
        prompt: "'Ida y vuelta' = return (there and back). 'Solo ida' = one way. Repeat both phrases.",
      },
      {
        type: "dialogue",
        foreign: "— Buenas. ¿Hay asientos disponibles para el bus de las dos a Santiago?\n— Sí, quedan cinco asientos. ¿Cuántos boletos quiere?\n— Dos, por favor. ¿Cuánto cuesta el boleto?\n— Son trescientos pesos cada uno. Son seiscientos en total.\n— ¿Me puede guardar los asientos de ventanilla?\n— Claro, no hay problema.",
        english: "— Hello. Are there seats available for the two o'clock bus to Santiago?\n— Yes, there are five seats left. How many tickets do you want?\n— Two, please. How much is the ticket?\n— It's three hundred pesos each. Six hundred in total.\n— Can you keep me the window seats?\n— Of course, no problem.",
        prompt: "Listen for '¿Quedan asientos?' — are there seats left? Repeat the passenger's lines.",
      },
      {
        type: "phrase",
        foreign: "¿Me puede llevar a...? ¿Cuánto me cobra para ir a...?",
        english: "Can you take me to...? How much do you charge to go to...?",
        prompt: "Essential taxi phrases. Repeat both — they'll save you every time.",
      },
      {
        type: "story",
        foreign: "En la República Dominicana, los 'carros públicos' son taxis compartidos que siguen rutas fijas y cuestan muy poco. No tienen taxímetro: el precio está establecido por ruta. Para parar uno, simplemente levanta la mano. Cuando quieras bajar, di: '¡La parada aquí, por favor!' o simplemente '¡Aquí!' y el conductor se detendrá.",
        english: "In the Dominican Republic, 'carros públicos' are shared taxis that follow fixed routes and cost very little. They have no meter — the price is set by route. To stop one, simply raise your hand. When you want to get off, say: 'Stop here please!' or simply 'Here!' and the driver will stop.",
      },
      {
        type: "practice",
        foreign: "Disculpe, ¿este autobús para en el aeropuerto? ¿Cuánto tarda en llegar?",
        english: "Excuse me, does this bus stop at the airport? How long does it take to get there?",
        prompt: "Ask these two questions clearly, as if you're on a bus right now.",
      },
    ],
  },
  {
    title: "Health and Body",
    nativeTitle: "La salud y el cuerpo",
    difficulty: 4,
    estimatedMinutes: 15,
    theme: "Describing symptoms, at the doctor",
    segments: [
      {
        type: "intro",
        english: "This lesson covers health vocabulary — body parts, describing pain, and visiting a doctor. Even if you stay healthy, you'll use this vocabulary when others are sick, when reading news, or simply when describing how you feel.",
      },
      {
        type: "phrase",
        foreign: "Me duele la cabeza. Me duele el estómago. Me duele la garganta.",
        english: "My head hurts. My stomach hurts. My throat hurts.",
        prompt: "'Me duele' + body part = it hurts me / I have pain. Repeat all three.",
      },
      {
        type: "phrase",
        foreign: "Me siento mal. Tengo fiebre. Estoy muy cansado/a.",
        english: "I feel unwell. I have a fever. I am very tired.",
        prompt: "General health expressions. Repeat each one.",
      },
      {
        type: "dialogue",
        foreign: "— Buenos días. Necesito ver a un médico con urgencia.\n— ¿Qué le ocurre?\n— Llevo dos días con fiebre alta y me duele mucho la cabeza. También tengo la garganta muy inflamada.\n— Siéntese, el doctor lo atenderá en diez minutos.\n(Más tarde)\n— Tiene usted una infección bacteriana. Voy a recetarle antibióticos y un antiinflamatorio.",
        english: "— Good morning. I need to see a doctor urgently.\n— What is wrong with you?\n— I've had a high fever for two days and my head hurts a lot. My throat is also very inflamed.\n— Take a seat, the doctor will see you in ten minutes.\n(Later)\n— You have a bacterial infection. I'm going to prescribe you antibiotics and an anti-inflammatory.",
        prompt: "'Llevo dos días con fiebre' — I've had a fever for two days. Notice 'llevar' used for duration. Repeat the patient's lines.",
      },
      {
        type: "story",
        foreign: "En la República Dominicana, muchos barrios tienen una farmacia de guardia abierta las veinticuatro horas. Es común ir directamente a la farmacia para pedir consejo al farmacéutico antes de ir al médico. Los farmacéuticos dominicanos son muy serviciales y pueden recomendar medicamentos sin receta para casos leves como resfriados, dolores de cabeza o alergias.",
        english: "In the Dominican Republic, many neighborhoods have a duty pharmacy open twenty-four hours. It is common to go directly to the pharmacy to ask the pharmacist's advice before visiting a doctor. Dominican pharmacists are very helpful and can recommend over-the-counter medicines for mild cases like colds, headaches, or allergies.",
      },
      {
        type: "practice",
        foreign: "Doctor, llevo tres días sintiéndome mal. Me duele la cabeza, tengo fiebre y no puedo dormir bien.",
        english: "Doctor, I've been feeling unwell for three days. My head hurts, I have a fever, and I can't sleep well.",
        prompt: "Say your symptoms clearly to the doctor.",
      },
    ],
  },
  {
    title: "At the Restaurant",
    nativeTitle: "En el restaurante",
    difficulty: 4,
    estimatedMinutes: 15,
    theme: "Full dining experience and expressing opinions",
    segments: [
      {
        type: "intro",
        english: "Today you'll experience a full Dominican restaurant visit from start to finish. You'll learn to read a menu, order confidently, express opinions about the food, and deal with common problems. Dominican cuisine is rich and varied — a perfect setting for language practice.",
      },
      {
        type: "phrase",
        foreign: "¿Tienen mesa para dos personas? ¿Me puede traer la carta, por favor?",
        english: "Do you have a table for two? Could you bring me the menu, please?",
        prompt: "Your opening lines at a restaurant. Repeat both.",
      },
      {
        type: "phrase",
        foreign: "¿Qué me recomienda? ¿Cuál es el plato del día?",
        english: "What do you recommend? What is the dish of the day?",
        prompt: "These questions show confidence. Repeat them.",
      },
      {
        type: "dialogue",
        foreign: "— Buenas noches. ¿Tienen mesa libre?\n— Sí, claro. ¿Para cuántas personas?\n— Somos tres.\n— Por aquí, por favor. ¿Les traigo la carta?\n— Sí, gracias. Y también agua, por favor.\n(Más tarde)\n— ¿Están listos para pedir?\n— Sí. Yo voy a pedir el mofongo con camarones. Mis amigos quieren el chivo guisado y el pescado frito.\n— Excelente elección. El chivo hoy está especialmente bueno.",
        english: "— Good evening. Do you have a free table?\n— Yes, of course. For how many people?\n— There are three of us.\n— This way, please. Shall I bring you the menu?\n— Yes, please. And water too.\n(Later)\n— Are you ready to order?\n— Yes. I'm going to order the mofongo with shrimp. My friends want the stewed goat and the fried fish.\n— Excellent choice. The goat today is especially good.",
        prompt: "'Excelente elección' — excellent choice. A classic waiter compliment! Repeat the diner's ordering lines.",
      },
      {
        type: "story",
        foreign: "El mofongo es el plato nacional de la República Dominicana. Se prepara aplastando plátanos verdes con ajo y chicharrón en un pilón de madera. Se puede servir solo o relleno de camarones, pulpo, carne o langosta. Cuando el mesero lo trae a la mesa, el olor es irresistible. Es uno de esos platos que hay que probar al menos una vez en la vida.",
        english: "Mofongo is the national dish of the Dominican Republic. It is made by mashing green plantains with garlic and pork crackling in a wooden mortar. It can be served plain or filled with shrimp, octopus, meat, or lobster. When the waiter brings it to the table, the smell is irresistible. It is one of those dishes you must try at least once in a lifetime.",
      },
      {
        type: "practice",
        foreign: "Disculpe, creo que hay un error en la cuenta. Yo pedí el mofongo con camarones, no el chivo.",
        english: "Excuse me, I think there's an error in the bill. I ordered the mofongo with shrimp, not the goat.",
        prompt: "Politely correct a mistake on your bill. Say it calmly and clearly.",
      },
    ],
  },
  {
    title: "A Day in Santo Domingo",
    nativeTitle: "Un día en Santo Domingo",
    difficulty: 5,
    estimatedMinutes: 16,
    theme: "Complex narration, past tense, idiomatic expressions",
    segments: [
      {
        type: "intro",
        english: "You've reached lesson fourteen — the most advanced lesson so far. Today you'll encounter the 'pretérito indefinido' — the simple past tense — and richer, more idiomatic Spanish. This is the kind of language native speakers use in everyday conversation.",
      },
      {
        type: "phrase",
        foreign: "Fui al museo. Visité la Ciudad Colonial. Comí mofongo por primera vez.",
        english: "I went to the museum. I visited the Colonial City. I ate mofongo for the first time.",
        prompt: "'Fui', 'visité', 'comí' are all past tense forms. This is the 'pretérito indefinido'. Repeat all three sentences.",
      },
      {
        type: "story",
        foreign: "Ayer, James y su amiga Dana pasaron un día inolvidable en Santo Domingo. Por la mañana, visitaron la Ciudad Colonial, declarada Patrimonio de la Humanidad. Recorrieron las calles empedradas, entraron en la catedral más antigua de América y tomaron fotos en las murallas. A mediodía, almorzaron en un restaurante típico donde comieron mofongo de camarones. Por la tarde, fueron al Malecón a ver el mar. Dana dijo: 'Este lugar es mágico.' James sonrió y respondió: 'Y apenas hemos visto la mitad.'",
        english: "Yesterday, James and his friend Dana spent an unforgettable day in Santo Domingo. In the morning, they visited the Colonial City, declared a World Heritage Site. They walked through the cobblestone streets, entered the oldest cathedral in the Americas, and took photos on the city walls. At noon, they had lunch at a typical restaurant where they ate shrimp mofongo. In the afternoon, they went to the Malecón to see the sea. Dana said: 'This place is magical.' James smiled and replied: 'And we've barely seen half of it.'",
      },
      {
        type: "dialogue",
        foreign: "— ¿Qué tal el día en Santo Domingo?\n— ¡Increíble! Hicimos un montón de cosas. La Ciudad Colonial me voló la mente.\n— ¿Fueron al Malecón?\n— Sí, al atardecer. El mar estaba precioso. Y la comida... el mofongo estaba de muerte.\n— ¡Me muero de envidia! ¿Cuándo vuelven?\n— Lo antes posible. Ya estoy echando de menos la ciudad.",
        english: "— How was the day in Santo Domingo?\n— Incredible! We did loads of things. The Colonial City blew my mind.\n— Did you go to the Malecón?\n— Yes, at sunset. The sea was beautiful. And the food... the mofongo was to die for.\n— I'm dying of envy! When are you going back?\n— As soon as possible. I already miss the city.",
        prompt: "'Me voló la mente' = blew my mind. 'Estaba de muerte' = to die for (food). 'Echando de menos' = missing. These are real idioms — listen, then repeat the traveller's lines.",
      },
      {
        type: "tip",
        english: "The pretérito indefinido (simple past) is used for completed actions in the past. Unlike French, Spanish has just one main conversational past tense for most situations in Latin America. Spain tends to use the 'perfecto' (he comido) for recent past, while Latin America uses the indefinido (comí) for both near and distant past.",
      },
      {
        type: "practice",
        foreign: "Ayer fui a la playa, comí mariscos y vi un atardecer increíble. Fue un día perfecto.",
        english: "Yesterday I went to the beach, ate seafood, and saw an incredible sunset. It was a perfect day.",
        prompt: "Say this sentence about your own perfect imaginary day. Then try substituting different activities.",
      },
      {
        type: "phrase",
        foreign: "Valió la pena. Estoy agotado/a pero muy feliz.",
        english: "It was worth it. I'm exhausted but very happy.",
        prompt: "'Valer la pena' = to be worth it — one of the most useful Spanish expressions. Repeat both sentences.",
      },
    ],
  },
];

export function getDailyStory(stories: Story[]): Story {
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 1).getTime()) / 86400000
  );
  return stories[dayOfYear % stories.length];
}
